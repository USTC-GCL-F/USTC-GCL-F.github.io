Each result contains four files:
1. 3D model.
2. Virtual scene (virtualscene.txt): the patches of reachable region. Each patch (rectangle) is represented by five numbers: #patch id, positions of four corners.
3. Mapping results (mapping.txt): the first line indicates twice the number of control points. The mapping on each patch is a Bezier surface that has 8*8 control points. Thus, a block containing 2*8*8 lines represents a Bezier surface (the even and odd lines mean x and y of one control point, respectively). The control points of a Bezier surface are ordered in columns (from left to right). In each column, they are from bottom to upper. 
4. Coordinate transformation (transfer.txt): transfer positions of 3D models into coordinate system of virtual scene. (a, b) belongs 3D models and (x, y) is in the virtual scene. 
