#ifndef CENTER_WIDGET_H
#define CENTER_WIDGET_H

#include <QtGui>
#include <QString>
#include <QMessageBox>
#include <QFileDialog>

#include "VolumeMeshParameterDialog.h"
#include "VolumeMeshViewer/InteractiveWidget.h"

//class centerWidget : public QSplitter
class centerWidget : public QDialog
{
	Q_OBJECT
public:
	centerWidget(QWidget* parent = 0);
	~centerWidget();

	void setDrawMode(int dm)
	{
		VolumeMeshViewer->setDrawMode(dm);
	}
	void setMouseMode(int dm)
	{
		VolumeMeshViewer->setMouseMode(dm);
		/*if(dm == InteractiveWidget::TRANS)
		{
			if( gp_hp->get_insert_mode() )
			{
				gp_hp->set_inserting_lines(true);
			}
			else
			{
				gp_hp->set_inserting_lines(false);
			}
		}*/
	}

	void saveOpenGLScreen()
	{
		QString fileName = QFileDialog::getSaveFileName(this,
			("Save screen as image file"),
			("../Debug_Information/Debug_Images/untitled.bmp"),
			("PNG Files (*.png);;BMP Files (*.bmp);;JPG Files (*.jpg);;"
			"All Files (*)"));
		if (!fileName.isEmpty())
		{
			save_screen_gui(fileName);
		}
	}

	void subdivideTetradetralMesh()
	{
		if(!LoadMeshSuccess) 
			return;
		
		VolumeMeshViewer->subdivide_Tet_TO_Hex();
	};

	void transform_mesh(std::vector<double>& tm)
	{
		if(!LoadMeshSuccess) 
			return;

		VolumeMeshViewer->transform_mesh(tm);
	}

	void create_grid_all_hex_mesh(int x_grid_size, int y_grid_size, int z_grid_size, double length = 1.0)
	{
		VolumeMeshViewer->create_grid_all_hex_mesh(x_grid_size,y_grid_size,z_grid_size,length);
	}

	void create_grid_mesh()
	{
		VolumeMeshViewer->create_grid_mesh_mesh();
	}

signals:
	void setMouseMode_signal_main(int);
	void setDrawMode_signal_main(int);

public:
	//debugInformation* debugDialog;
	parameterDialog* paramDialog;
	InteractiveWidget* VolumeMeshViewer;

private:
	bool LoadMeshSuccess;

public slots:
	void open_mesh_query()
	{
		QString fileName = QFileDialog::getOpenFileName(this,
			("Open mesh file"),
			("E:/Volume Mesh/Our_Volume_Models"),
			("OVM Files (*.ovm);;"
			"All Files (*)"));

		if (!fileName.isEmpty())
		{
			open_mesh_gui(fileName);
			emit(haveLoadMesh(fileName));
		}
	}
	void save_mesh_query() 
	{
		QString fileName = QFileDialog::getSaveFileName(this,
			("Save mesh file"),
			("E:/Volume Mesh/Our_Volume_Models/untitled.ovm"),
			("OVM Files (*.ovm);;VTK Files(*.vtk);;VOFF Files(*.voff);;TET Files(*.tet);;OFF Files(*.off);;"
			"All Files (*)"));
		if (!fileName.isEmpty())
		{
			save_mesh_gui(fileName);
		}
	}

	void clear_all_mesh()
	{
		if(LoadMeshSuccess)
		{
			LoadMeshSuccess = false;
			VolumeMeshViewer->clearAllMesh();
		}
		
	}

	void LoadMeshFromInner(bool OK, QString fname)
	{
		LoadMeshSuccess = OK;
		if(LoadMeshSuccess)
		{
			set_Mesh();
			emit( haveLoadMesh(fname) );
		}
	};

	void save_mesh_graph_query()
	{
		QString fileName = QFileDialog::getSaveFileName(this,
			("Save Mesh Graph"),
			("E:/Volume Mesh/Our_Volume_Models/graph.txt"),
			("TXT Files (*.txt);;"
			"All Files (*)"));
		if (!fileName.isEmpty())
		{
			VolumeMeshViewer->save_mesh_graph(fileName.toLocal8Bit());
		}
	}

	void save_hex_mesh_graph_query()
	{
		QString fileName = QFileDialog::getSaveFileName(this,
			("Save Hex Mesh Graph"),
			("E:/Volume Mesh/Our_Volume_Models/graph.txt"),
			("TXT Files (*.txt);;"
			"All Files (*)"));
		if (!fileName.isEmpty())
		{
			VolumeMeshViewer->save_hex_mesh_graph(fileName.toLocal8Bit());
		}
	}

	void construct_vertex_texture()
	{
		VolumeMeshViewer->construct_vertex_texture();
	}

signals:
	void haveLoadMesh(QString filePath);

private:
	void initDialog();
	void createWidget();
	void createLayout();
	void createslotsignal();

	void save_mesh_gui(QString fname);
	void open_mesh_gui(QString fname);
	void save_screen_gui(QString fname);

	void set_Mesh()
	{
		if(VolumeMeshViewer->meshMode() == InteractiveWidget::TETRAHEDRAL)
		{
		}
		else if(VolumeMeshViewer->meshMode() == InteractiveWidget::HEXAHEDRA)
		{
		}
	}
};


#endif