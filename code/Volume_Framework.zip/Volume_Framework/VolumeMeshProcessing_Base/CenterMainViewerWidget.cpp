#include "CenterMainViewerWidget.h"

centerWidget::centerWidget(QWidget* parent /* = 0 */)
	:QDialog(parent)
{
	initDialog();
}

centerWidget::~centerWidget()
{
}

void centerWidget::initDialog()
{
	createWidget();
	createLayout();
}

void centerWidget::createWidget()
{
	//debugDialog = new debugInformation();
	paramDialog = new parameterDialog();

	QGLFormat glFormat;
	glFormat.setSampleBuffers(true);
	glFormat.setSamples(16);

	VolumeMeshViewer = new InteractiveWidget(glFormat, NULL);
	VolumeMeshViewer->setAcceptDrops(true);
	LoadMeshSuccess = false;
}

void centerWidget::createLayout()
{
	//this->setOrientation( Qt::Horizontal );

	//this->addWidget(debugDialog);
	//OpenGL mesh viewer
	//this->addWidget(paramDialog);
	//this->addWidget(VolumeMeshViewer);

	//set the splitter line color
	//this->setStyleSheet("QSplitter::handle { background-color: green }");
	//QSplitterHandle* splitterHandle = this->handle(1);
	//splitterHandle->setDisabled(true);

	QHBoxLayout* main_layout = new QHBoxLayout();
	main_layout->addWidget(paramDialog, 1);
	main_layout->addWidget(VolumeMeshViewer, 5);

	this->setLayout(main_layout);

	createslotsignal();
}

void centerWidget::createslotsignal()
{
	connect(VolumeMeshViewer,SIGNAL(setMouseMode_signal(int)),SIGNAL(setMouseMode_signal_main(int)));
	connect(VolumeMeshViewer,SIGNAL(setDrawMode_signal(int)),SIGNAL(setDrawMode_signal_main(int)));

	connect(VolumeMeshViewer,SIGNAL(loadMeshOK(bool,QString)),this, SLOT(LoadMeshFromInner(bool,QString)) );

	connect(paramDialog, SIGNAL(draw_main_scene_signal(int)), VolumeMeshViewer,SLOT(set_draw_main_scene(int)));
	connect(paramDialog, SIGNAL(leftrightChanged(int)), VolumeMeshViewer,SLOT(showLeftRight(int)));
	connect(paramDialog, SIGNAL(updownChanged(int)), VolumeMeshViewer,SLOT(showUpDown(int)));
	connect(paramDialog, SIGNAL(backfrontChanged(int)), VolumeMeshViewer,SLOT(showBackFront(int)));
	connect(paramDialog, SIGNAL(xslidderChanged(int)), VolumeMeshViewer,SLOT(xSliderShow(int)));
	connect(paramDialog, SIGNAL(yslidderChanged(int)), VolumeMeshViewer,SLOT(ySliderShow(int)));
	connect(paramDialog, SIGNAL(zslidderChanged(int)), VolumeMeshViewer,SLOT(zSliderShow(int)));

	connect(paramDialog, SIGNAL(set_draw_inv_tet_signal(int)), VolumeMeshViewer,SLOT(set_draw_flipped_tet(int)));
	connect(paramDialog, SIGNAL(save_show_mesh_signal()), VolumeMeshViewer,SLOT(save_show_mesh()));
	connect(paramDialog, SIGNAL(save_mesh_graph_signal()), this, SLOT(save_mesh_graph_query()));
	connect(paramDialog, SIGNAL(save_mesh_graph_hex_signal()), this, SLOT(save_hex_mesh_graph_query()));
	connect(paramDialog, SIGNAL(construct_vertex_texture_signal()), this, SLOT(construct_vertex_texture()));
	//connect(paramDialog, SIGNAL(set_insert_mode_signal(bool)), this, SLOT(set_insert_mode(bool)));
	/*connect(paramDialog, SIGNAL(choose_point_signal()), this, SLOT(choose_point()));
	connect(paramDialog, SIGNAL(start_slider_changed(int)), this, SLOT(start_slider_changed_slot(int)));
	connect(paramDialog, SIGNAL(end_slider_changed(int)), this, SLOT(end_slider_changed_slot(int)));
	connect(paramDialog, SIGNAL(phi_slider_changed(int)), this, SLOT(phi_slider_changed_slot(int)));
	connect(paramDialog, SIGNAL(alpha_slider_changed(int)), this, SLOT(alpha_slider_changed_slot(int)));
	connect(paramDialog, SIGNAL(find_exist_end_signal()), this, SLOT(find_exist_end()));
	connect(paramDialog, SIGNAL(draw_active_lines_signal(int)), this, SLOT(draw_active_lines(int)));*/
	/*connect(gp_hp, SIGNAL(updateGL_Manual_signal()),VolumeMeshViewer,SLOT(UpdateGL_Manual_slot()));
	connect(VolumeMeshViewer, SIGNAL(draw_for_HP()), gp_hp, SLOT(draw_for_this_situation()));
	connect(VolumeMeshViewer, SIGNAL(change_to_insert_mode()), paramDialog, SLOT(change_insert_mode()));
	connect(VolumeMeshViewer, SIGNAL(draw_for_HP()), gp_hp, SLOT(draw_for_this_situation()));
	connect(VolumeMeshViewer, SIGNAL(pick_point_for_designing_hex_patch(OpenVolumeMesh::Geometry::Vec3d)), gp_hp, SLOT(pick_point_from_main(OpenVolumeMesh::Geometry::Vec3d)));
	connect(VolumeMeshViewer, SIGNAL(pick_line_for_designing_hex_patch(OpenVolumeMesh::Geometry::Vec3d)), gp_hp, SLOT(pick_line_from_main(OpenVolumeMesh::Geometry::Vec3d)));*/
}

void centerWidget::open_mesh_gui(QString fname)
{
	bool IsOpen = VolumeMeshViewer->openMesh(fname.toLocal8Bit());
	if (fname.isEmpty() || !IsOpen ) 
	{
		QString msg = "Cannot read mesh from file:\n '";
		msg += fname;
		msg += "'";
		QMessageBox::critical(NULL, windowTitle(), msg);
	}
	else
	{
		//VolumeMeshViewer->detectDoublet();
		LoadMeshSuccess = true;
		if(LoadMeshSuccess)
		{
			set_Mesh();
		}
	}
}

void centerWidget::save_mesh_gui(QString fname)
{
	bool writeFile= false;
	if(fname.endsWith(".vtk"))
	{
		writeFile = VolumeMeshViewer->saveMesh_VTK(fname.toLocal8Bit());
	}
	else if(fname.endsWith(".tet"))
	{
		writeFile = VolumeMeshViewer->saveMesh_Tet(fname.toLocal8Bit());
	}
	else if(fname.endsWith(".voff"))
	{
		writeFile = VolumeMeshViewer->saveMesh_VOFF(fname.toLocal8Bit());
	}
	else if(fname.endsWith(".off"))
	{
		writeFile = VolumeMeshViewer->saveBoundaryMesh(fname.toLocal8Bit());
	}
	else
	{
		writeFile = VolumeMeshViewer->saveMesh(fname.toLocal8Bit());
	}
	if (fname.isEmpty() || !writeFile)
	{
		QString msg = "Cannot save mesh to file:\n '";
		msg += fname;
		msg += "'";
		QMessageBox::critical(NULL, windowTitle(), msg);
	}
}

void centerWidget::save_screen_gui(QString fname)
{
	if (fname.isEmpty() || !VolumeMeshViewer->SaveScreen(fname.toLocal8Bit()))
	{
		QString msg = "Cannot save image to file:\n '";
		msg += fname;
		msg += "'";
		QMessageBox::critical(NULL, windowTitle(), msg);
	}
}

//void centerWidget::set_insert_mode(bool OK)
//{
//	VolumeMeshViewer->setFunction_HP(OK);
//	gp_hp->set_insert_mode(OK);
//}
//
//void centerWidget::choose_point()
//{
//	int id = paramDialog->get_choose_point();
//	if(id == MeshField::POINT_ON_SURFACE)
//	{
//		gp_hp->set_choose_point_surface(true);
//	}
//	else
//	{
//		gp_hp->set_choose_point_surface(false);
//	}
//}
//
//void centerWidget::start_slider_changed_slot(int value)
//{
//	double per = value / Utility_Definition::max_length_slider;
//	gp_hp->set_len_start_active_line(per);
//}
//
//void centerWidget::end_slider_changed_slot(int value)
//{
//	double per = value / Utility_Definition::max_length_slider;
//	gp_hp->set_len_end_active_line(per);
//}
//
//void centerWidget::phi_slider_changed_slot(int value)
//{
//	double per = value / Utility_Definition::max_angle_slider;
//	gp_hp->set_phi_active_line(per);
//}
//
//void centerWidget::alpha_slider_changed_slot(int value)
//{
//	double per = value / Utility_Definition::max_angle_slider;
//	gp_hp->set_alpha_active_line(per);
//}
//
//void centerWidget::find_exist_end()
//{
//
//}
//
//void centerWidget::draw_active_lines(int state)
//{
//	gp_hp->set_draw_active_lines(state == Qt::Checked);
//}
