#ifndef AUX_TRANSFORM_MESH_H
#define AUX_TRANSFORM_MESH_H

#include <QDialog>
#include <QtGui>
#include <QtWidgets>

class aux_transform_mesh_dialog : public QDialog
{
	Q_OBJECT
private:
	QPushButton *m_OKButton;
	QPushButton *m_CancelButton;
	QLineEdit* m11; QLineEdit* m12; QLineEdit* m13; QLineEdit* m14;
	QLineEdit* m21; QLineEdit* m22; QLineEdit* m23; QLineEdit* m24;
	QLineEdit* m31; QLineEdit* m32; QLineEdit* m33; QLineEdit* m34;
	QLineEdit* m41; QLineEdit* m42; QLineEdit* m43; QLineEdit* m44;

public:
	aux_transform_mesh_dialog(QWidget *parent = 0)
		: QDialog(parent)
	{
		m11 = new QLineEdit("1.0"); m12 = new QLineEdit("0.0"); m13 = new QLineEdit("0.0"); m14 = new QLineEdit("0.0");
		m21 = new QLineEdit("0.0"); m22 = new QLineEdit("1.0"); m23 = new QLineEdit("0.0"); m24 = new QLineEdit("0.0");
		m31 = new QLineEdit("0.0"); m32 = new QLineEdit("0.0"); m33 = new QLineEdit("1.0"); m34 = new QLineEdit("0.0");
		m41 = new QLineEdit("0.0"); m42 = new QLineEdit("0.0"); m43 = new QLineEdit("0.0"); m44 = new QLineEdit("1.0");
		m_OKButton = new QPushButton("OK"); m_CancelButton = new QPushButton("Cancel");
		QGridLayout* t_layout = new QGridLayout();
		t_layout->addWidget(m11, 0, 0, 1, 1); t_layout->addWidget(m12, 0, 1, 1, 1); t_layout->addWidget(m13, 0, 2, 1, 1); t_layout->addWidget(m14, 0, 3, 1, 1);
		t_layout->addWidget(m21, 1, 0, 1, 1); t_layout->addWidget(m22, 1, 1, 1, 1); t_layout->addWidget(m23, 1, 2, 1, 1); t_layout->addWidget(m24, 1, 3, 1, 1);
		t_layout->addWidget(m31, 2, 0, 1, 1); t_layout->addWidget(m32, 2, 1, 1, 1); t_layout->addWidget(m33, 2, 2, 1, 1); t_layout->addWidget(m34, 2, 3, 1, 1);
		t_layout->addWidget(m41, 3, 0, 1, 1); t_layout->addWidget(m42, 3, 1, 1, 1); t_layout->addWidget(m43, 3, 2, 1, 1); t_layout->addWidget(m44, 3, 3, 1, 1);
		t_layout->addWidget(m_CancelButton, 4, 0, 1, 2); t_layout->addWidget(m_OKButton, 4, 2, 1, 2);
		
		this->setLayout(t_layout);
		this->setWindowTitle("Transform Matrix");
		this->resize(300, 150);
		connect(m_OKButton, SIGNAL(clicked()), this, SLOT(accept()));  
		connect(m_CancelButton, SIGNAL(clicked()), this, SLOT(reject())); 
	}
	~aux_transform_mesh_dialog()
	{
		delete m11; delete m12; delete m13; delete m14;
		delete m21; delete m22; delete m23; delete m24; 
		delete m31; delete m32; delete m33; delete m34; 
		delete m41; delete m42; delete m43; delete m44; 
	};

	void get_transform_matrix(std::vector<double>& m)
	{
		m.resize(16);
		m[0]  = m11->text().toDouble(); m[1]  = m12->text().toDouble(); m[2]  = m13->text().toDouble(); m[3]  = m14->text().toDouble();
		m[4]  = m21->text().toDouble(); m[5]  = m22->text().toDouble(); m[6]  = m23->text().toDouble(); m[7]  = m24->text().toDouble();
		m[8]  = m31->text().toDouble(); m[9]  = m32->text().toDouble(); m[10] = m33->text().toDouble(); m[11] = m34->text().toDouble();
		m[12] = m41->text().toDouble(); m[13] = m42->text().toDouble(); m[14] = m43->text().toDouble(); m[15] = m44->text().toDouble();
	}

	virtual void accept() { QDialog::accept(); }
	virtual void reject() { QDialog::reject(); }
};

class create_all_hex_grid_mesh_dialog : public QDialog
{
	Q_OBJECT
private:
	QPushButton *m_OKButton;
	QPushButton *m_CancelButton;
	QLineEdit* w; QLineEdit* h; QLineEdit* l;
	QLabel* w_label; QLabel* h_label; QLabel* l_label;
public:
	create_all_hex_grid_mesh_dialog(QWidget *parent = 0)
		: QDialog(parent)
	{
		//x y z
		w = new QLineEdit("10"); h = new QLineEdit("10"); l = new QLineEdit("40");
		w_label = new QLabel("X_Grid:");
		h_label = new QLabel("Y_Grid:");
		l_label = new QLabel("Z_Grid:");
		m_OKButton = new QPushButton("OK"); m_CancelButton = new QPushButton("Cancel");
		QGridLayout* t_layout = new QGridLayout();
		t_layout->addWidget(w_label, 0, 0, 1, 1); t_layout->addWidget(w, 0, 1, 1, 1);
		t_layout->addWidget(h_label, 1, 0, 1, 1); t_layout->addWidget(h, 1, 1, 1, 1);
		t_layout->addWidget(l_label, 2, 0, 1, 1); t_layout->addWidget(l, 2, 1, 1, 1);
		t_layout->addWidget(m_CancelButton, 3, 0, 1, 1); t_layout->addWidget(m_OKButton, 3, 1, 1, 1);

		this->setLayout(t_layout);
		this->setWindowTitle("Grid Mesh Size");
		this->resize(200, 150);
		connect(m_OKButton, SIGNAL(clicked()), this, SLOT(accept()));
		connect(m_CancelButton, SIGNAL(clicked()), this, SLOT(reject()));
	};

	~create_all_hex_grid_mesh_dialog()
	{
		delete w; delete h; delete l;
		delete w_label; delete h_label; delete l_label;
	};

	void get_w_h_l(int& w_, int& h_, int& l_)
	{
		w_ = w->text().toInt();
		h_ = h->text().toInt();
		l_ = l->text().toInt();
	}

	virtual void accept() { QDialog::accept(); }
	virtual void reject() { QDialog::reject(); }
};

#endif