/****************************************************************************
** Meta object code from reading C++ file 'surfacemeshprocessing.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../surfacemeshprocessing.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'surfacemeshprocessing.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SurfaceMeshProcessing_t {
    QByteArrayData data[41];
    char stringdata0[634];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SurfaceMeshProcessing_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SurfaceMeshProcessing_t qt_meta_stringdata_SurfaceMeshProcessing = {
    {
QT_MOC_LITERAL(0, 0, 21), // "SurfaceMeshProcessing"
QT_MOC_LITERAL(1, 22, 4), // "save"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 6), // "saveAs"
QT_MOC_LITERAL(4, 35, 17), // "setMouseMode_slot"
QT_MOC_LITERAL(5, 53, 2), // "mm"
QT_MOC_LITERAL(6, 56, 16), // "setDrawMode_slot"
QT_MOC_LITERAL(7, 73, 2), // "dm"
QT_MOC_LITERAL(8, 76, 13), // "wireFrameShow"
QT_MOC_LITERAL(9, 90, 15), // "hiddenLinesShow"
QT_MOC_LITERAL(10, 106, 13), // "solidFlatShow"
QT_MOC_LITERAL(11, 120, 14), // "flatPointsShow"
QT_MOC_LITERAL(12, 135, 15), // "solidSmoothShow"
QT_MOC_LITERAL(13, 151, 12), // "pointSetShow"
QT_MOC_LITERAL(14, 164, 13), // "curvatureShow"
QT_MOC_LITERAL(15, 178, 8), // "DrawBBox"
QT_MOC_LITERAL(16, 187, 16), // "DrawMeshBoundary"
QT_MOC_LITERAL(17, 204, 9), // "pointPick"
QT_MOC_LITERAL(18, 214, 10), // "vertexPick"
QT_MOC_LITERAL(19, 225, 8), // "edgePick"
QT_MOC_LITERAL(20, 234, 8), // "facePick"
QT_MOC_LITERAL(21, 243, 10), // "moveVertex"
QT_MOC_LITERAL(22, 254, 9), // "edit_undo"
QT_MOC_LITERAL(23, 264, 20), // "set_edit_undo_enable"
QT_MOC_LITERAL(24, 285, 1), // "b"
QT_MOC_LITERAL(25, 287, 9), // "edit_redo"
QT_MOC_LITERAL(26, 297, 20), // "set_edit_redo_enable"
QT_MOC_LITERAL(27, 318, 13), // "edge_collpase"
QT_MOC_LITERAL(28, 332, 9), // "edge_flip"
QT_MOC_LITERAL(29, 342, 10), // "edge_split"
QT_MOC_LITERAL(30, 353, 29), // "aux_inverse_mesh_connectivity"
QT_MOC_LITERAL(31, 383, 19), // "aux_scale_mesh_BBox"
QT_MOC_LITERAL(32, 403, 19), // "aux_split_quad_mesh"
QT_MOC_LITERAL(33, 423, 18), // "aux_transform_mesh"
QT_MOC_LITERAL(34, 442, 24), // "aux_find_vertex_by_index"
QT_MOC_LITERAL(35, 467, 22), // "aux_find_edge_by_index"
QT_MOC_LITERAL(36, 490, 22), // "aux_find_face_by_index"
QT_MOC_LITERAL(37, 513, 26), // "aux_find_vertex_by_valance"
QT_MOC_LITERAL(38, 540, 30), // "aux_delete_vertex_valence_four"
QT_MOC_LITERAL(39, 571, 31), // "aux_delete_vertex_valence_three"
QT_MOC_LITERAL(40, 603, 30) // "aux_split_vertex_valence_eight"

    },
    "SurfaceMeshProcessing\0save\0\0saveAs\0"
    "setMouseMode_slot\0mm\0setDrawMode_slot\0"
    "dm\0wireFrameShow\0hiddenLinesShow\0"
    "solidFlatShow\0flatPointsShow\0"
    "solidSmoothShow\0pointSetShow\0curvatureShow\0"
    "DrawBBox\0DrawMeshBoundary\0pointPick\0"
    "vertexPick\0edgePick\0facePick\0moveVertex\0"
    "edit_undo\0set_edit_undo_enable\0b\0"
    "edit_redo\0set_edit_redo_enable\0"
    "edge_collpase\0edge_flip\0edge_split\0"
    "aux_inverse_mesh_connectivity\0"
    "aux_scale_mesh_BBox\0aux_split_quad_mesh\0"
    "aux_transform_mesh\0aux_find_vertex_by_index\0"
    "aux_find_edge_by_index\0aux_find_face_by_index\0"
    "aux_find_vertex_by_valance\0"
    "aux_delete_vertex_valence_four\0"
    "aux_delete_vertex_valence_three\0"
    "aux_split_vertex_valence_eight"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SurfaceMeshProcessing[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      36,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  194,    2, 0x08 /* Private */,
       3,    0,  195,    2, 0x08 /* Private */,
       4,    1,  196,    2, 0x08 /* Private */,
       6,    1,  199,    2, 0x08 /* Private */,
       8,    0,  202,    2, 0x08 /* Private */,
       9,    0,  203,    2, 0x08 /* Private */,
      10,    0,  204,    2, 0x08 /* Private */,
      11,    0,  205,    2, 0x08 /* Private */,
      12,    0,  206,    2, 0x08 /* Private */,
      13,    0,  207,    2, 0x08 /* Private */,
      14,    0,  208,    2, 0x08 /* Private */,
      15,    0,  209,    2, 0x08 /* Private */,
      16,    0,  210,    2, 0x08 /* Private */,
      17,    0,  211,    2, 0x08 /* Private */,
      18,    0,  212,    2, 0x08 /* Private */,
      19,    0,  213,    2, 0x08 /* Private */,
      20,    0,  214,    2, 0x08 /* Private */,
      21,    0,  215,    2, 0x08 /* Private */,
      22,    0,  216,    2, 0x08 /* Private */,
      23,    1,  217,    2, 0x08 /* Private */,
      25,    0,  220,    2, 0x08 /* Private */,
      26,    1,  221,    2, 0x08 /* Private */,
      27,    0,  224,    2, 0x08 /* Private */,
      28,    0,  225,    2, 0x08 /* Private */,
      29,    0,  226,    2, 0x08 /* Private */,
      30,    0,  227,    2, 0x08 /* Private */,
      31,    0,  228,    2, 0x08 /* Private */,
      32,    0,  229,    2, 0x08 /* Private */,
      33,    0,  230,    2, 0x08 /* Private */,
      34,    0,  231,    2, 0x08 /* Private */,
      35,    0,  232,    2, 0x08 /* Private */,
      36,    0,  233,    2, 0x08 /* Private */,
      37,    0,  234,    2, 0x08 /* Private */,
      38,    0,  235,    2, 0x08 /* Private */,
      39,    0,  236,    2, 0x08 /* Private */,
      40,    0,  237,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   24,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void SurfaceMeshProcessing::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SurfaceMeshProcessing *_t = static_cast<SurfaceMeshProcessing *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: { bool _r = _t->save();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 1: { bool _r = _t->saveAs();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 2: _t->setMouseMode_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->setDrawMode_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->wireFrameShow(); break;
        case 5: _t->hiddenLinesShow(); break;
        case 6: _t->solidFlatShow(); break;
        case 7: _t->flatPointsShow(); break;
        case 8: _t->solidSmoothShow(); break;
        case 9: _t->pointSetShow(); break;
        case 10: _t->curvatureShow(); break;
        case 11: _t->DrawBBox(); break;
        case 12: _t->DrawMeshBoundary(); break;
        case 13: _t->pointPick(); break;
        case 14: _t->vertexPick(); break;
        case 15: _t->edgePick(); break;
        case 16: _t->facePick(); break;
        case 17: _t->moveVertex(); break;
        case 18: _t->edit_undo(); break;
        case 19: _t->set_edit_undo_enable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->edit_redo(); break;
        case 21: _t->set_edit_redo_enable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->edge_collpase(); break;
        case 23: _t->edge_flip(); break;
        case 24: _t->edge_split(); break;
        case 25: _t->aux_inverse_mesh_connectivity(); break;
        case 26: _t->aux_scale_mesh_BBox(); break;
        case 27: _t->aux_split_quad_mesh(); break;
        case 28: _t->aux_transform_mesh(); break;
        case 29: _t->aux_find_vertex_by_index(); break;
        case 30: _t->aux_find_edge_by_index(); break;
        case 31: _t->aux_find_face_by_index(); break;
        case 32: _t->aux_find_vertex_by_valance(); break;
        case 33: _t->aux_delete_vertex_valence_four(); break;
        case 34: _t->aux_delete_vertex_valence_three(); break;
        case 35: _t->aux_split_vertex_valence_eight(); break;
        default: ;
        }
    }
}

const QMetaObject SurfaceMeshProcessing::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_SurfaceMeshProcessing.data,
      qt_meta_data_SurfaceMeshProcessing,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *SurfaceMeshProcessing::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SurfaceMeshProcessing::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_SurfaceMeshProcessing.stringdata0))
        return static_cast<void*>(const_cast< SurfaceMeshProcessing*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int SurfaceMeshProcessing::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 36)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 36)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 36;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
