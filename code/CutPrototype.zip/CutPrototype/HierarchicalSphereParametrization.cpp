#include "HierarchicalSphereParametrization.h"

HierarchicalSphereParametrization::HierarchicalSphereParametrization(Mesh &mesh)
{
	origin_mesh = mesh;
	copy_origin_mesh = mesh;
	copy_origin_mesh1 = mesh;
	n_vertices = origin_mesh.n_vertices();
	std::cout << "origin_mesh: " << n_vertices << std::endl;
	n_edges = origin_mesh.n_edges();
	std::cout << "origin_mesh: " << n_edges << std::endl;
	n_faces = origin_mesh.n_faces();
	std::cout << "origin_mesh: " << n_faces << std::endl;
	current_num_v = n_vertices;
	current_num_e = n_edges;
	current_num_f = n_faces;
	origin_mesh.add_property(ecost);
	copy_origin_mesh.add_property(ecost);
	origin_mesh.add_property(vindex);
	copy_origin_mesh.add_property(vindex);
	calc_vindex(origin_mesh);
	calc_vindex(copy_origin_mesh);
	radius = ComputeSphereRadius(origin_mesh);
	std::cout << "radius : " << radius << std::endl;
	first_sub = true;
	is_in_sphere = false;
	maxmum = -1e20;

	//maxmum = 1e20;

	origin_mesh.add_property(QuaMat_f);
	origin_mesh.add_property(QuaMat_v);
	origin_mesh.add_property(QuaMat_e);
	origin_mesh.add_property(area_f);
	origin_mesh.add_property(new_point);
	//origin_mesh.add_property(edge_l);
	//	origin_mesh.add_property(origin_position);
	//	calc_origin_position(origin_mesh);
	/*for (auto it = origin_mesh.vertices_begin(); it != origin_mesh.vertices_end(); ++it)
	{
	cout<<origin_mesh.property(vindex,it)<<endl;;
	}*/
	bcd_v_optimization = new BCD_Volume_Sphere_Optimization();
	bcd_v_optimization->SetThreshhold(1e-8, 1e-8);

	origin_mesh.add_property(is_cal_e);
	origin_mesh.add_property(is_cal_he);
	for (auto e_it = origin_mesh.edges_begin(); e_it != origin_mesh.edges_end(); ++e_it)
	{
		origin_mesh.property(is_cal_e, *e_it) = false;
		Mesh::HalfedgeHandle he_it = origin_mesh.halfedge_handle(*e_it, 0);
		origin_mesh.property(is_cal_he, he_it) = false;
		he_it = origin_mesh.halfedge_handle(*e_it, 1);
		origin_mesh.property(is_cal_he, he_it) = false;
	}
}

HierarchicalSphereParametrization::~HierarchicalSphereParametrization(void)
{
	if (bcd_v_optimization)
	{
		delete bcd_v_optimization;
		bcd_v_optimization = nullptr;
	}
}

std::vector<std::vector<int>> HierarchicalSphereParametrization::do_Simplify()
{
	QEM_Simplify(2000, 1e-4);
	LaplacianSmooth(origin_mesh, 3);
	origin_mesh.release_vertex_normals();

	//bcd_optimization = new BCD_Sphere_Optimization();
	//string s = to_string(current_num_v);
	//bcd_optimization->PrintObj("after_qem",&origin_mesh);
	//delete bcd_optimization;

	int counter = 0;
	Initial_Halfedge_Cost(origin_mesh);
	//Initial_Halfedge_Cost_pengchao(origin_mesh);
	//index_collapse_v_to_v.clear();
	while (Choose_Collapased_edge(origin_mesh))
	{
		counter++;
		/*if (counter > 1000)
		{
		origin_mesh.garbage_collection(true);
		break;
		}*/
		/*if (counter%100 ==0)
		{
		origin_mesh.garbage_collection(true);
		bcd_optimization = new BCD_Sphere_Optimization();
		string s = to_string(current_num_v);
		bcd_optimization->PrintObj("cem_" + s, &origin_mesh);
		delete bcd_optimization;
		Initial_Halfedge_Cost(origin_mesh);
		}*/
		/*if (find(recore_add_v_nun.begin(),recore_add_v_nun.end(),current_num_v) != recore_add_v_nun.end())
		{
		origin_mesh.garbage_collection(true);
		bcd_optimization = new BCD_Sphere_Optimization();
		string s = to_string(current_num_v);
		bcd_optimization->PrintObj("cem_" + s, &origin_mesh);
		delete bcd_optimization;
		Initial_Halfedge_Cost(origin_mesh);
		}*/
		if (current_num_v == 4)
		{
			origin_mesh.garbage_collection(true);
			/*bcd_optimization = new BCD_Sphere_Optimization();
			string s = to_string(current_num_v);
			bcd_optimization->PrintObj(s, &origin_mesh);
			delete bcd_optimization;*/
			//Initial_Halfedge_Cost(origin_mesh);
			break;
		}
	}
	n_edges = n_faces = 0;
	for (auto it = origin_mesh.edges_begin(); it != origin_mesh.edges_end(); ++it)
	{
		n_edges++;
	}
	current_num_e = n_edges;
	for (auto it = origin_mesh.faces_begin(); it != origin_mesh.faces_end(); ++it)
	{
		n_faces++;
	}
	current_num_f = n_faces;
	std::cout << "n_vertices: " << current_num_v << "  n_edges:  " << current_num_e << "  n_faces:  " << current_num_f << std::endl;
	std::cout << "Simplify is over!  the iter number is:  " << counter << std::endl;
	first_sub = true;
	return index_collapse_v_to_v;
}

void HierarchicalSphereParametrization::LaplacianSmooth(Mesh &m, int iter_num_)
{
	Mesh::VIter     v_it, v_end(m.vertices_end());
	Mesh::CVVIter   vv_it;
	Mesh::Point     u, n;
	m.request_vertex_normals();
	//m.update_vertex_normals();
	for (int iter = 0; iter < iter_num_; iter++)
	{
		Mesh::Point             centroid(0.0, 0.0, 0.0);
		/*std::vector<Mesh::Normal> normals;
		for (v_it=m.vertices_begin(); v_it!=v_end; ++v_it)
		{
		Mesh::Normal n = m.normal(v_it);
		normals.push_back(n);
		}*/
		int k = 0;
		for (v_it = m.vertices_begin(); v_it != v_end; ++v_it)
		{
			if (!m.is_boundary(*v_it))
			{
				int i = 0;
				centroid[0] = 0.0; centroid[1] = 0.0; centroid[2] = 0.0;
				for (vv_it = m.vv_iter(*v_it); vv_it.is_valid(); ++vv_it)
				{
					centroid += m.point(*vv_it);
					i++;
				}
				centroid = ((float)1.0 / i)*centroid;
				centroid -= m.point(*v_it);
				centroid *= (float)0.5;

				//centroid = normals[k]%(centroid%normals[k]);
				centroid = m.point(*v_it) + centroid;
				m.set_point(*v_it, centroid);
			}
			k++;
		}
	}
	m.update_normals();
}

void HierarchicalSphereParametrization::calc_vindex(Mesh& m)
{
	int i = 0;
	for (auto it = m.vertices_begin(); it != m.vertices_end(); ++it)
	{
		m.property(vindex, *it) = i;
		i++;
	}
}

void HierarchicalSphereParametrization::calc_origin_position(Mesh& m)
{
	for (auto it = m.vertices_begin(); it != m.vertices_end(); ++it)
	{
		m.property(origin_position, *it) = m.point(*it);
		o_p.push_back(m.point(*it));
	}
}

bool HierarchicalSphereParametrization::Restore_Last_mesh(Mesh &m, std::vector<int> &reco_info)
{
	/*bcd_v_optimization = new BCD_Volume_Sphere_Optimization();
	bcd_v_optimization->SetThreshhold(1e-8, 1e-8);
	bcd_v_optimization->SetMesh(&m);
	bool is_overlap = bcd_v_optimization->checklap(&m, 1e-12);
	if (is_overlap)
	{
	cout << "the result have overlap" << endl;
	}
	else
	{
	cout << "the result do not have overlap" << endl;
	}
	delete  bcd_v_optimization;
	bcd_v_optimization = NULL;*/

	Mesh::VertexHandle v_l, v_r, v_n;
	Mesh::Point p(0, 0, 0);
	Mesh::VertexHandle it = m.vertex_handle(idx_to_idx_corresponding[reco_info[1]]);
	v_l = m.vertex_handle(idx_to_idx_corresponding[reco_info[2]]);
	v_r = m.vertex_handle(idx_to_idx_corresponding[reco_info[3]]);
	m.vertex_split(p, it, v_l, v_r);
	bool is_add_ok = Add_One_Point(m, m.vertex_handle(m.n_vertices() - 1), it, 10);
	bool is_add_ok_after_op = false;
	if (!is_add_ok)
	{
		int counter = 0;
		while (!is_add_ok_after_op)
		{
			is_add_ok_after_op = OptimizeOneRing(m, m.vertex_handle(m.n_vertices() - 1), it, 10);
			counter++;

			if (counter > 5)
			{
				break;
			}
		}
	}
	if ((!is_add_ok_after_op) && (!is_add_ok))
	{
		std::cout << "can not add vertex anymore ! current vertices:  " << current_num_v << std::endl;

		for (auto he = m.voh_iter(m.vertex_handle(m.n_vertices() - 1)); he.is_valid(); ++he)
		{
			Mesh::VertexHandle v = m.to_vertex_handle(*he);
			if (v == it)
			{
				m.collapse(*he);
				m.garbage_collection(true);
				break;
			}
		}

		/*bcd_optimization = new BCD_Sphere_Optimization();
		string s = to_string(current_num_v);
		bcd_optimization->PrintObj(s + "_faild_", &origin_mesh);
		delete bcd_optimization;
		bcd_optimization = new BCD_Sphere_Optimization(&origin_mesh, 1.0);
		bcd_optimization->prepare_parameterization(bcd_optimization->mesh);
		bcd_optimization->do_EXP_parameterizing(1.0, 0.5, 100);
		delete  bcd_optimization;
		bcd_optimization = NULL;*/

		bcd_v_optimization->SetMesh(&m);
		bcd_v_optimization->optimize_sphere_volume(0.5, 50);
		bcd_v_optimization->optimize_sphere_volume(0.5, 50);
		bcd_v_optimization->optimize_sphere_volume(0.5, 50);
		bcd_v_optimization->compute_distortion();

		m.vertex_split(p, it, v_l, v_r);
		bool is_add_ok = Add_One_Point(m, m.vertex_handle(m.n_vertices() - 1), it, 10);
		if (is_add_ok)
		{
			m.property(vindex, m.vertex_handle(m.n_vertices() - 1)) = reco_info[0];
			return true;
		}
		for (auto he = m.voh_iter(m.vertex_handle(m.n_vertices() - 1)); he.is_valid(); ++he)
		{
			Mesh::VertexHandle v = m.to_vertex_handle(*he);
			if (v == it)
			{
				origin_mesh.collapse(*he);
				m.garbage_collection(true);
				break;
			}
		}
		return false;
	}
	else
	{
		m.property(vindex, m.vertex_handle(m.n_vertices() - 1)) = reco_info[0];
		return true;
	}
}

bool HierarchicalSphereParametrization::Add_One_Point(Mesh &m, Mesh::VertexHandle v_f, Mesh::VertexHandle v_t, int c)
{
	std::vector<double> energy_dis_; energy_dis_.reserve(100);
	std::vector<Mesh::Point> s_p; s_p.reserve(100);
	std::vector<Mesh::Point> n_p_cross; n_p_cross.reserve(16);
	std::vector<Mesh::Point> np1; np1.reserve(16);
	std::vector<Mesh::Point> np2; np2.reserve(16);
	double vol_ = 0.0;
	nei_ps1.clear(); nei_ps1.reserve(16);
	for (auto he_it = m.voh_iter(v_f); he_it.is_valid(); ++he_it)
	{
		Mesh::VertexHandle v1 = m.to_vertex_handle(*he_it);
		Mesh::Point p1 = m.point(v1);
		np1.push_back(p1);
		Mesh::VertexHandle v2 = m.to_vertex_handle(m.next_halfedge_handle(*he_it));
		Mesh::Point p2 = m.point(v2);
		np2.push_back(p2);
		Mesh::Point cross_p1_p2 = p1%p2;
		n_p_cross.push_back(cross_p1_p2);
		Mesh::Point p0 = m.point(v_t);
		vol_ += p0 | cross_p1_p2;
		nei_ps1.push_back(v1.idx());
	}
	vol_ /= m.valence(v_f);

	for (auto he_it = m.voh_iter(v_f); he_it.is_valid(); ++he_it)
	{
		Mesh::VertexHandle v1 = m.to_vertex_handle(*he_it);
		Mesh::Point p1 = m.point(v1);
		Mesh::VertexHandle v2 = m.to_vertex_handle(m.next_halfedge_handle(*he_it));
		Mesh::Point p2 = m.point(v2);
		if ((v1 != v_t) && (v2 != v_t))
		{
			Mesh::Point p0 = m.point(v_t);
			Mesh::Point mid_p;
			for (int i = 0; i < c; i++)
			{
				for (int j = 0; j < (c - i); j++)
				{
					mid_p = ((double)i / c)*p1 + ((double)j / c)*p2 + ((double)(c - i - j) / c)*p0;
					mid_p = mid_p / mid_p.norm();
					bool sig = local_check_negative_area(mid_p, n_p_cross);
					if (sig)
					{
						energy_dis_.push_back(local_isotropy_energy(mid_p, np1, np2, vol_));
						s_p.push_back(mid_p);
					}
				}
			}
		}
	}
	if (!energy_dis_.size())
	{
		//		nei_ps1 = np1;
		//		nei_ps2 = np2;
		return false;
	}
	else
	{
		//		ComputeBihedralAngles(m,v_f);
		int idx = min_element(energy_dis_.begin(), energy_dis_.end()) - energy_dis_.begin();
		m.set_point(v_f, s_p[idx]);
		return true;
	}
}

double HierarchicalSphereParametrization::local_isotropy_energy(Mesh::Point &p, std::vector<Mesh::Point> &np1, std::vector<Mesh::Point> &np2, double vol_)
{
	double dis_nenrgy = 0.0; double aspect_ratio, vol_dis;
	for (int i = 0; i < np1.size(); i++)
	{
		double a = (np1[i] - p).norm();
		double b = (np2[i] - p).norm();
		double c = (np1[i] - np2[i]).norm();
		aspect_ratio = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
		double v = p | (np1[i] % np2[i]);
		vol_dis = v / vol_ + vol_ / v;
		dis_nenrgy += (aspect_ratio*vol_dis);
	}
	return dis_nenrgy;
}

bool HierarchicalSphereParametrization::local_check_negative_area(Mesh::Point &p, std::vector<Mesh::Point> &n_p)
{
	for (int i = 0; i < n_p.size(); i++)
	{
		if ((p | n_p[i]) < 1e-12)
		{
			return false;
		}
	}
	return true;
}

void HierarchicalSphereParametrization::QEM_Simplify(int tar_num_v, double err_threshhold)
{
	Initial_Edge_QEM_cost(origin_mesh);
	index_collapse_v_to_v.clear(); index_collapse_v_to_v.reserve(n_vertices);
	int counter = 0;
	while (Choose_Collapased_edge_qem(origin_mesh, err_threshhold))
	{
		counter++;
		/*if (counter>100)
		{
		origin_mesh.garbage_collection(true);
		break;
		}*/
		/*if (counter%500 == 0)
		{
		origin_mesh.garbage_collection(true);
		bcd_optimization = new BCD_Sphere_Optimization();
		string s = to_string(current_num_v);
		bcd_optimization->PrintObj("qem_" + s, &origin_mesh);
		delete bcd_optimization;
		Initial_Edge_QEM_cost(origin_mesh);
		}*/
		/*if (find(recore_add_v_nun.begin(), recore_add_v_nun.end(), current_num_v) != recore_add_v_nun.end())
		{
		origin_mesh.garbage_collection(true);
		bcd_optimization = new BCD_Sphere_Optimization();
		string s = to_string(current_num_v);
		bcd_optimization->PrintObj("qem_" + s, &origin_mesh);
		delete bcd_optimization;
		Initial_Edge_QEM_cost(origin_mesh);
		}*/
		if (current_num_v < (tar_num_v + 1))
		{
			origin_mesh.garbage_collection(true);
			/*simplified_mesh.clear();
			for (auto v_it = origin_mesh.vertices_begin(); v_it != origin_mesh.vertices_end(); ++v_it)
			{
			std::cout << "ori idx: " << origin_mesh.property(vindex, v_it) << std::endl;
			simplified_mesh.push_back(origin_mesh.property(vindex, v_it));
			}*/
			break;
		}
	}
	n_edges = n_faces = 0;
	for (auto it = origin_mesh.edges_begin(); it != origin_mesh.edges_end(); ++it)
	{
		n_edges++;
	}
	current_num_e = n_edges;
	for (auto it = origin_mesh.faces_begin(); it != origin_mesh.faces_end(); ++it)
	{
		n_faces++;
	}
	current_num_f = n_faces;
	std::cout << "n_vertices: " << current_num_v << "  n_edges:  " << current_num_e << "  n_faces:  " << current_num_f << std::endl;
	std::cout << "Simplify is over!  the iter number is:  " << counter << std::endl;
}

bool HierarchicalSphereParametrization::Choose_Collapased_edge_qem(Mesh &m, double err_threshhold)
{
	//int edge_len = 0;
	EdgeQEM currentEdge;
	bool done = false;
	int valence = 0;

	do
	{
		done = false;
		if (qpq.size() == 0)
		{
			done = true;
			m.garbage_collection(true);
			return false;
		}
		else
		{
			currentEdge = qpq.top();
			qpq.pop();
			valence = m.valence(m.from_vertex_handle(m.halfedge_handle(currentEdge.idx, 0)));
			valence += m.valence(m.to_vertex_handle(m.halfedge_handle(currentEdge.idx, 0)));
		}
	} while ((m.status(m.edge_handle(m.halfedge_handle(currentEdge.idx, 0))).deleted()) || (m.property(QuaMat_e, currentEdge.idx) != currentEdge.qem) || (valence > 12));
	if (currentEdge.qem < err_threshhold)
	{
		Mesh::HalfedgeHandle idx = m.halfedge_handle(currentEdge.idx, 0);
		std::vector<int> re_in(4);
		re_in[0] = m.property(vindex, m.from_vertex_handle(idx));
		re_in[1] = m.property(vindex, m.to_vertex_handle(idx));
		re_in[2] = m.property(vindex, m.to_vertex_handle(m.next_halfedge_handle(idx)));
		re_in[3] = m.property(vindex, m.to_vertex_handle(m.next_halfedge_handle(m.opposite_halfedge_handle(idx))));
		index_collapse_v_to_v.push_back(re_in);
		OpenMesh::Vec3d& p = m.property(new_point, currentEdge.idx);
		m.set_point(m.to_vertex_handle(idx), p);
		/*if (p.norm() >2.0)
		{
		std::cout << p << std::endl;
		}*/
		int update_p = m.to_vertex_handle(idx).idx();
		m.collapse(idx);
		Update_Edge_QEM_cost(m, update_p);
		current_num_v--;
		return true;
	}
	else
	{
		m.garbage_collection(true);
		std::cout << "can not collapsed anymore !   " << "Current minimize qem is : " << currentEdge.qem << std::endl;
		return false;
	}
}

bool HierarchicalSphereParametrization::Choose_Collapased_edge(Mesh &m)
{
	EdgeInfo currentEdge;
	bool done = false;
	do
	{
		done = false;
		if (epq.size() == 0)
		{
			done = true;
			break;
		}
		else
		{
			currentEdge = epq.top();
			epq.pop();
			//cout << m.status(m.edge_handle(currentEdge.idx)).deleted() << endl;
		}
	} while ((m.status(m.edge_handle(currentEdge.idx)).deleted()) || (m.property(ecost, currentEdge.idx) != currentEdge.ecost));

	if (currentEdge.ecost > maxmum)
	{
		Mesh::HalfedgeHandle idx = currentEdge.idx;
		std::vector<int> update_v;  update_v.reserve(16);
		for (auto vv_it = m.vv_begin(m.from_vertex_handle(idx)); vv_it != m.vv_end(m.from_vertex_handle(idx)); ++vv_it)
		{
			int idx_vv_it = vv_it->idx();
			update_v.push_back(idx_vv_it);
		}
		std::vector<int> re_in(4);
		re_in[0] = m.property(vindex, m.from_vertex_handle(idx));
		re_in[1] = m.property(vindex, m.to_vertex_handle(idx));
		re_in[2] = m.property(vindex, m.to_vertex_handle(m.next_halfedge_handle(idx)));
		re_in[3] = m.property(vindex, m.to_vertex_handle(m.next_halfedge_handle(m.opposite_halfedge_handle(idx))));
		index_collapse_v_to_v.push_back(re_in);
		m.collapse(idx);

		//		m.garbage_collection(true);
		//		Mesh::VertexHandle v_it = m.vertex_handle(idx_v_t);
		for (int i = 0; i < update_v.size(); i++)
		{
			Update_Halfedge_Cost(m, update_v[i]);
		}
		for (int i = 0; i < update_v.size(); i++)
		{
			Mesh::VertexHandle v_it = m.vertex_handle(update_v[i]);
			for (auto e_it = m.voh_iter(v_it); e_it.is_valid(); ++e_it)
			{
				m.property(is_cal_he, *e_it) = false;
			}
			for (auto e_it = m.vih_iter(v_it); e_it.is_valid(); ++e_it)
			{
				m.property(is_cal_he, *e_it) = false;
			}
		}
		current_num_v--;
		return true;
	}
	else
	{
		m.garbage_collection(true);
		std::cout << "can not collapsed anymore !" << std::endl;
		return false;
	}
}

bool HierarchicalSphereParametrization::Choose_Collapased_edge_pengchao(Mesh &m)
{
	//Initial_Halfedge_Cost_pengchao(m);
	//EdgeInfo_ currentEdge;
	//bool done = false;
	//do
	//{
	//	done = false;
	//	if (epq_p.size() == 0)
	//	{
	//		done = true;
	//		break;
	//	}
	//	else
	//	{
	//		currentEdge = epq_p.top();
	//		epq_p.pop();
	//		//cout << currentEdge.ecost << "  " << m.edge_handle(currentEdge.idx).idx() <<"  " <<epq_p.size()<< endl;
	//	}
	//} while ((m.status(m.edge_handle(currentEdge.idx)).deleted()) || (m.property(ecost, currentEdge.idx) != currentEdge.ecost));
	double  c = 1e20; Mesh::HalfedgeHandle idx = *m.halfedges_begin();
	for (auto he_it = m.halfedges_begin(); he_it != m.halfedges_end(); ++he_it)
	{
		double cost = m.property(ecost, *he_it);
		if (c > cost)
		{
			c = cost;
			idx = *he_it;
		}
	}

	if (c < maxmum)
	{
		//cout <<c<<"  "<< idx.idx() <<" "<<m.n_halfedges()<< endl;
		//Mesh::HalfedgeHandle idx = currentEdge.idx;
		std::vector<int> update_v;  update_v.reserve(16);
		for (auto vv_it = m.vv_begin(m.from_vertex_handle(idx)); vv_it != m.vv_end(m.from_vertex_handle(idx)); ++vv_it)
		{
			int idx_vv_it = vv_it->idx();
			if (idx_vv_it != (m.n_vertices() - 1))
			{
				update_v.push_back(idx_vv_it);
			}
		}
		std::vector<int> re_in(4);
		re_in[0] = m.property(vindex, m.from_vertex_handle(idx));
		re_in[1] = m.property(vindex, m.to_vertex_handle(idx));
		re_in[2] = m.property(vindex, m.to_vertex_handle(m.next_halfedge_handle(idx)));
		re_in[3] = m.property(vindex, m.to_vertex_handle(m.next_halfedge_handle(m.opposite_halfedge_handle(idx))));
		index_collapse_v_to_v.push_back(re_in);
		m.collapse(idx);
		//cout << c << "  " << idx.idx() << " " << m.n_halfedges() << endl;

		m.garbage_collection(true);
		//		Mesh::VertexHandle v_it = m.vertex_handle(idx_v_t);
		for (int i = 0; i < update_v.size(); i++)
		{
			Update_Halfedge_Cost_pengchao(m, update_v[i]);
		}
		for (int i = 0; i < update_v.size(); i++)
		{
			Mesh::VertexHandle v_it = m.vertex_handle(update_v[i]);
			for (auto e_it = m.voh_iter(v_it); e_it.is_valid(); ++e_it)
			{
				m.property(is_cal_he, *e_it) = false;
			}
			for (auto e_it = m.vih_iter(v_it); e_it.is_valid(); ++e_it)
			{
				m.property(is_cal_he, *e_it) = false;
			}
		}
		current_num_v--;
		return true;
	}
	else
	{
		m.garbage_collection(true);
		std::cout << "can not collapsed anymore !" << std::endl;
		return false;
	}
}

void HierarchicalSphereParametrization::Initial_Halfedge_Cost(Mesh &m)
{
	std::vector<EdgeInfo> initial_e_cost(m.n_halfedges());
	EdgeInfo e;

	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		for (auto e_it = m.voh_iter(*v_it); e_it.is_valid(); ++e_it)
		{
			Mesh::VertexHandle v_f = m.from_vertex_handle(*e_it);
			Mesh::VertexHandle v_t = m.to_vertex_handle(*e_it);
			Mesh::FaceHandle f1 = m.face_handle(*e_it), f2 = m.face_handle(m.opposite_halfedge_handle(*e_it));
			std::vector<std::vector<Mesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
			double gauss_c = 0, area_ = 0;
			for (auto he_it = m.voh_iter(v_f); he_it.is_valid(); ++he_it)
			{
				Mesh::HalfedgeHandle h0 = m.next_halfedge_handle(*he_it);
				Mesh::HalfedgeHandle h1 = m.prev_halfedge_handle(*he_it);
				Mesh::HalfedgeHandle h2 = *he_it;
				Mesh::Point p1 = m.point(m.to_vertex_handle(h2));
				Mesh::Point p2 = m.point(m.to_vertex_handle(h0));
				Mesh::Point p0 = m.point(m.to_vertex_handle(h1));
				double t = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
				double theta = acos(t);
				gauss_c += theta;
				t = ((p1 - p0) % (p2 - p0)).norm() / 2.0;
				area_ += t;
				Mesh::FaceHandle f = m.face_handle(*he_it);
				if ((f != f1) && (f != f2))
				{
					std::vector<Mesh::Point> mid_e(2);
					mid_e[0] = p1;
					mid_e[1] = p2;
					nighbors_edge.push_back(mid_e);
				}
			}

			if (!m.is_collapse_ok(*e_it))
			{
				m.property(ecost, *e_it) = maxmum;
				e.ecost = maxmum; e.idx = *e_it;
				initial_e_cost[e_it->idx()] = e;
			}
			else
			{
				for (auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((*fv_it != f1) && (*fv_it != f2))
					{
						std::vector<Mesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(*fv_it); f_v != m.fv_end(*fv_it); ++f_v)
						{
							if (*f_v != v_t)
							{
								Mesh::Point p = m.point(*f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					Mesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
					if (fabs(a_r) > 100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				int devi_valence = nighbors_edge.size() - 6;
				aspect_ratio *= fmath::expd((double)(devi_valence*devi_valence));
				//				double c = aspect_ratio/(1.0 + fabs(2.0*3.14159 - gauss_c)/(area_/3.0));
				double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost, *e_it) = c;
				e.ecost = c; e.idx = *e_it;
				initial_e_cost[e_it->idx()] = e;
			}
		}
	}
	std::priority_queue<EdgeInfo> epq_(initial_e_cost.begin(), initial_e_cost.end());
	epq = epq_;
	//	delete &epq_;
}

void HierarchicalSphereParametrization::Initial_Halfedge_Cost_pengchao(Mesh &m)
{
	std::vector<EdgeInfo_> initial_e_cost(m.n_halfedges());
	EdgeInfo_ e;

	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		for (auto e_it = m.voh_iter(*v_it); e_it.is_valid(); ++e_it)
		{
			Mesh::VertexHandle v_f = m.from_vertex_handle(*e_it);
			Mesh::VertexHandle v_t = m.to_vertex_handle(*e_it);
			Mesh::FaceHandle f1 = m.face_handle(*e_it), f2 = m.face_handle(m.opposite_halfedge_handle(*e_it));
			std::vector<std::vector<Mesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
			double gauss_c = 0, area_ = 0;
			for (auto he_it = m.voh_iter(v_f); he_it.is_valid(); ++he_it)
			{
				Mesh::HalfedgeHandle h0 = m.next_halfedge_handle(*he_it);
				Mesh::HalfedgeHandle h1 = m.prev_halfedge_handle(*he_it);
				Mesh::HalfedgeHandle h2 = *he_it;
				Mesh::Point p1 = m.point(m.to_vertex_handle(h2));
				Mesh::Point p2 = m.point(m.to_vertex_handle(h0));
				Mesh::Point p0 = m.point(m.to_vertex_handle(h1));
				double t = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
				double theta = acos(t);
				gauss_c += theta;
				t = ((p1 - p0) % (p2 - p0)).norm() / 2.0;
				area_ += t;
				Mesh::FaceHandle f = m.face_handle(*he_it);
				if ((f != f1) && (f != f2))
				{
					std::vector<Mesh::Point> mid_e(2);
					mid_e[0] = p1;
					mid_e[1] = p2;
					nighbors_edge.push_back(mid_e);
				}
			}

			if (!m.is_collapse_ok(*e_it))
			{
				m.property(ecost, *e_it) = maxmum;
				e.ecost = maxmum; e.idx = *e_it;
				initial_e_cost[e_it->idx()] = e;
			}
			else
			{
				for (auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((*fv_it != f1) && (*fv_it != f2))
					{
						std::vector<Mesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(*fv_it); f_v != m.fv_end(*fv_it); ++f_v)
						{
							if (*f_v != v_t)
							{
								Mesh::Point p = m.point(*f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					Mesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
					if (fabs(a_r) > 100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				//int devi_valence = nighbors_edge.size() - 6;
				//aspect_ratio *= fmath::expd((double)(devi_valence*devi_valence));
				double c = aspect_ratio / (1.0 + (2.0*3.14159 - gauss_c) / (area_ / 3.0));
				if (fabs(1.0 + (2.0*3.14159 - gauss_c) / (area_ / 3.0)) < 1e-10)
				{
					c = maxmum;
				}
				//double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost, *e_it) = c;
				e.ecost = c; e.idx = *e_it;
				initial_e_cost[e_it->idx()] = e;
			}
		}
	}
	//priority_queue<EdgeInfo_> epq_(initial_e_cost.begin(), initial_e_cost.end());
	//epq_p = epq_;
}

void HierarchicalSphereParametrization::Initial_Edge_QEM_cost(Mesh &m)
{
	std::vector<EdgeQEM> initial_e_qem_cost(m.n_edges());
	EdgeQEM e;
	m.request_face_normals();
	m.update_face_normals();
	for (auto f_it = m.faces_begin(); f_it != m.faces_end(); ++f_it)
	{
		OpenMesh::Vec3d n = m.normal(*f_it);
		Mesh::FaceVertexIter fv_it = m.fv_iter(*f_it);
		OpenMesh::Vec3d& p = m.point(*fv_it);
		++fv_it; OpenMesh::Vec3d& p1 = m.point(*fv_it);
		++fv_it; OpenMesh::Vec3d& p2 = m.point(*fv_it);
		double area_ = ((p1 - p) % (p2 - p)).norm();
		m.property(area_f, *f_it) = area_;

		double a = n[0]; double b = n[1]; double c = n[2]; double d = -(n | p);
		Eigen::Matrix4d mat;
		mat << a*a, a*b, a*c, a*d,
			b*a, b*b, b*c, b*d,
			c*a, c*b, c*c, c*d,
			d*a, d*b, d*c, d*d;
		m.property(QuaMat_f, *f_it) = mat;
		//		cout << n << endl;
	}
	m.release_face_normals();

	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		Eigen::Matrix4d mat = Eigen::Matrix4d::Zero();
		for (auto vf_it = m.vf_begin(*v_it); vf_it != m.vf_end(*v_it); ++vf_it)
		{
			//mat += m.property(area_f, vf_it)*m.property(QuaMat_f, vf_it);
			mat += m.property(QuaMat_f, *vf_it);
		}
		m.property(QuaMat_v, *v_it) = mat;
	}

	for (auto e_it = m.edges_begin(); e_it != m.edges_end(); ++e_it)
	{
		Mesh::HalfedgeHandle he = m.halfedge_handle(*e_it, 0);
		Mesh::VertexHandle  v0 = m.to_vertex_handle(he);
		Mesh::VertexHandle  v1 = m.from_vertex_handle(he);
		Eigen::Matrix4d mat = m.property(QuaMat_v, v0) + m.property(QuaMat_v, v1);

		Eigen::Matrix4d mid_m = mat;  mid_m(3, 0) = mid_m(3, 1) = mid_m(3, 2) = 0.0; mid_m(3, 3) = 1.0;
		Eigen::Vector4d b(0.0, 0.0, 0.0, 1.0);
		//		Eigen::Vector4d v = mid_m.colPivHouseholderQr().solve(b);
		Eigen::Vector4d v;
		OpenMesh::Vec3d new_p;
		if (fabs(mid_m.determinant()) < 1e-4)
		{
			new_p = (m.point(v0) + m.point(v1)) / 2;
			/*if (new_p.norm() > 2.0)
			{
			std::cout << "mid:  " << new_p.norm() << std::endl;
			}*/
		}
		else
		{
			v = mid_m.colPivHouseholderQr().solve(b);
			//v = mid_m.lu().solve(b);
			new_p[0] = v(0); new_p[1] = v(1); new_p[2] = v(2);
			/*if (new_p.norm() > 2.0)
			{
			std::cout << "qr:  " << new_p.norm() << std::endl;
			}*/
		}
		m.property(new_point, *e_it) = new_p;
		double err = v.transpose()*mat*v;
		/*if (err < 0)
		{
		int ustc = 1;
		}*/
		err *= (m.valence(v0) * m.valence(v1));
		if (m.is_collapse_ok(he))
		{
			m.property(QuaMat_e, *e_it) = err;
			e.qem = err;
			e.idx = *e_it;
			initial_e_qem_cost[e_it->idx()] = e;
		}
		else
		{
			m.property(QuaMat_e, *e_it) = -maxmum;
			e.qem = -maxmum;
			e.idx = *e_it;
			initial_e_qem_cost[e_it->idx()] = e;
		}
		//m.property(edge_l, e_it) = m.calc_edge_length(e_it);
	}
	std::priority_queue<EdgeQEM> qpq_(initial_e_qem_cost.begin(), initial_e_qem_cost.end());
	qpq = qpq_;
}

void HierarchicalSphereParametrization::Update_Edge_QEM_cost(Mesh &m, int i)
{
	EdgeQEM e;
	Mesh::VertexHandle v_it = m.vertex_handle(i);
	Eigen::Matrix4d q_mat = Eigen::Matrix4d::Zero();
	for (auto vf_it = m.vf_begin(v_it); vf_it != m.vf_end(v_it); ++vf_it)
	{
		Mesh::FaceVertexIter fv_it = m.fv_iter(*vf_it);
		OpenMesh::Vec3d& p = m.point(*fv_it);
		++fv_it; OpenMesh::Vec3d& p1 = m.point(*fv_it);
		++fv_it; OpenMesh::Vec3d& p2 = m.point(*fv_it);
		double area_ = ((p1 - p) % (p2 - p)).norm();
		m.property(area_f, *vf_it) = area_;

		OpenMesh::Vec3d& n = ((p1 - p) % (p2 - p)).normalize();
		double a = n[0]; double b = n[1]; double c = n[2]; double d = -(n | p);
		Eigen::Matrix4d mat;
		mat << a*a, a*b, a*c, a*d,
			b*a, b*b, b*c, b*d,
			c*a, c*b, c*c, c*d,
			d*a, d*b, d*c, d*d;
		m.property(QuaMat_f, *vf_it) = mat;
		q_mat += mat;
	}
	m.property(QuaMat_v, v_it) = q_mat;

	for (auto vv_it = m.vv_begin(v_it); vv_it != m.vv_end(v_it); ++vv_it)
	{
		q_mat = Eigen::Matrix4d::Zero();
		for (auto vvf_it = m.vf_begin(*vv_it); vvf_it != m.vf_end(*vv_it); ++vvf_it)
		{
			//q_mat += m.property(area_f,vvf_it)*m.property(QuaMat_f, vvf_it);
			q_mat += m.property(QuaMat_f, *vvf_it);
		}
		m.property(QuaMat_v, *vv_it) = q_mat;
	}


	for (auto vv_it = m.vv_begin(v_it); vv_it != m.vv_end(v_it); ++vv_it)
	{
		for (auto e_it = m.ve_begin(*vv_it); e_it != m.ve_end(*vv_it); ++e_it)
		{
			if (!m.property(is_cal_e, *e_it))
			{
				Mesh::HalfedgeHandle he = m.halfedge_handle(*e_it, 0);
				Mesh::VertexHandle  v0 = m.to_vertex_handle(he);
				Mesh::VertexHandle  v1 = m.from_vertex_handle(he);
				Eigen::Matrix4d mat = m.property(QuaMat_v, v0) + m.property(QuaMat_v, v1);
				Eigen::Matrix4d mid_m = mat;  mid_m(3, 0) = mid_m(3, 1) = mid_m(3, 2) = 0.0; mid_m(3, 3) = 1.0;
				Eigen::Vector4d b(0.0, 0.0, 0.0, 1.0);
				//Eigen::Vector4d v = mid_m.colPivHouseholderQr().solve(b);
				//OpenMesh::Vec3d new_p(v(0), v(1), v(2));
				Eigen::Vector4d v;
				OpenMesh::Vec3d new_p;
				if (fabs(mid_m.determinant()) < 1e-4)
				{
					//cout << mid_m.determinant()<< endl;
					new_p = (m.point(v0) + m.point(v1)) / 2;
				}
				else
				{
					//v = mid_m.lu().solve(b);
					v = mid_m.colPivHouseholderQr().solve(b);
					new_p[0] = v(0); new_p[1] = v(1); new_p[2] = v(2);
				}
				m.property(new_point, *e_it) = new_p;
				double err = v.transpose()*mat*v;
				err *= (m.valence(v0) * m.valence(v1));
				if (m.is_collapse_ok(he) && m.is_collapse_ok(m.opposite_halfedge_handle(he)))
				{

					m.property(QuaMat_e, *e_it) = err;
					e.qem = err;
					e.idx = *e_it;
					qpq.push(e);
					//cout <<m.from_vertex_handle(he).idx() <<"  "<<m.to_vertex_handle(he).idx()<< endl;
				}
				else
				{
					m.property(QuaMat_e, *e_it) = -maxmum;
				}
				//m.property(edge_l, e_it) = m.calc_edge_length(e_it);
				m.property(is_cal_e, *e_it) = true;
			}
		}
	}
	for (auto vv_it = m.vv_begin(v_it); vv_it != m.vv_end(v_it); ++vv_it)
	{
		for (auto e_it = m.ve_begin(*vv_it); e_it != m.ve_end(*vv_it); ++e_it)
		{
			m.property(is_cal_e, *e_it) = false;
		}
	}
}

void HierarchicalSphereParametrization::Update_Halfedge_Cost(Mesh &m, int i)
{
	EdgeInfo e;
	Mesh::VertexHandle v_it = m.vertex_handle(i);
	for (auto e_it = m.voh_iter(v_it); e_it.is_valid(); ++e_it)
	{
		if (!m.property(is_cal_he, *e_it))
		{
			//cout << m.property(is_cal_he, e_it) << endl;
			if (!m.is_collapse_ok(*e_it))
			{
				m.property(ecost, *e_it) = maxmum;
				//			e.idx = e_it.handle(); e.ecost = maxmum;
				//			epq.push(e);
			}
			else
			{
				Mesh::VertexHandle v_f = m.from_vertex_handle(*e_it);
				Mesh::VertexHandle v_t = m.to_vertex_handle(*e_it);
				Mesh::FaceHandle f1 = m.face_handle(*e_it), f2 = m.face_handle(m.opposite_halfedge_handle(*e_it));
				std::vector<std::vector<Mesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
				double gauss_c = 0, area_ = 0;
				for (auto he_it = m.voh_iter(v_f); he_it.is_valid(); ++he_it)
				{
					Mesh::HalfedgeHandle h0 = m.next_halfedge_handle(*he_it);
					Mesh::HalfedgeHandle h1 = m.prev_halfedge_handle(*he_it);
					Mesh::HalfedgeHandle h2 = *he_it;
					Mesh::Point p1 = m.point(m.to_vertex_handle(h2));
					Mesh::Point p2 = m.point(m.to_vertex_handle(h0));
					Mesh::Point p0 = m.point(m.to_vertex_handle(h1));
					double t = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
					double theta = acos(t);
					if (t < -0.9999)
					{
						theta = 3.14159;
					}
					if (t > 0.9999)
					{
						theta = 0.0;
					}
					gauss_c += theta;
					t = ((p1 - p0) % (p2 - p0)).norm() / 2.0;
					area_ += t;
					Mesh::FaceHandle f = m.face_handle(*he_it);
					if ((f != f1) && (f != f2))
					{
						std::vector<Mesh::Point> mid_e(2);
						mid_e[0] = p1;
						mid_e[1] = p2;
						nighbors_edge.push_back(mid_e);
					}
				}

				for (auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((*fv_it != f1) && (*fv_it != f2))
					{
						std::vector<Mesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(*fv_it); f_v != m.fv_end(*fv_it); ++f_v)
						{
							if (*f_v != v_t)
							{
								Mesh::Point p = m.point(*f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					Mesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
					if (fabs(a_r) > 100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				//		aspect_ratio *= nighbors_edge.size();
				int devi_valence = nighbors_edge.size() - 6;
				aspect_ratio *= fmath::expd((double)(devi_valence*devi_valence));
				//		 aspect_ratio  *= std::exp((double)nighbors_edge.size());
				if (area_ < 0.00001)
				{
					area_ = 0.00001;
				}
				//				double c = aspect_ratio/(1.0 + fabs(2.0*3.14159 - gauss_c)/(area_/3.0));
				double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost, *e_it) = c;
				e.ecost = c; e.idx = *e_it;
				epq.push(e);
			}
			m.property(is_cal_he, *e_it) = true;
		}
	}

	for (auto e_it = m.vih_iter(v_it); e_it.is_valid(); ++e_it)
	{
		if (!m.property(is_cal_he, *e_it))
		{
			//cout << m.property(is_cal_he, e_it) << endl;
			if (!m.is_collapse_ok(*e_it))
			{
				m.property(ecost, *e_it) = maxmum;
			}
			else
			{
				Mesh::VertexHandle v_f = m.from_vertex_handle(*e_it);
				Mesh::VertexHandle v_t = m.to_vertex_handle(*e_it);
				Mesh::FaceHandle f1 = m.face_handle(*e_it), f2 = m.face_handle(m.opposite_halfedge_handle(*e_it));
				std::vector<std::vector<Mesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
				double gauss_c = 0, area_ = 0;
				for (auto he_it = m.voh_iter(v_f); he_it.is_valid(); ++he_it)
				{
					Mesh::HalfedgeHandle h0 = m.next_halfedge_handle(*he_it);
					Mesh::HalfedgeHandle h1 = m.prev_halfedge_handle(*he_it);
					Mesh::HalfedgeHandle h2 = *he_it;
					Mesh::Point p1 = m.point(m.to_vertex_handle(h2));
					Mesh::Point p2 = m.point(m.to_vertex_handle(h0));
					Mesh::Point p0 = m.point(m.to_vertex_handle(h1));
					double t = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
					double theta = acos(t);
					if (t < -0.9999)
					{
						theta = 3.14159;
					}
					if (t > 0.9999)
					{
						theta = 0.0;
					}
					gauss_c += theta;
					t = ((p1 - p0) % (p2 - p0)).norm() / 2.0;
					area_ += t;
					Mesh::FaceHandle f = m.face_handle(*he_it);
					if ((f != f1) && (f != f2))
					{
						std::vector<Mesh::Point> mid_e(2);
						mid_e[0] = p1;
						mid_e[1] = p2;
						nighbors_edge.push_back(mid_e);
					}
				}

				for (auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((*fv_it != f1) && (*fv_it != f2))
					{
						std::vector<Mesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(*fv_it); f_v != m.fv_end(*fv_it); ++f_v)
						{
							if (*f_v != v_t)
							{
								Mesh::Point p = m.point(*f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					Mesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
					if (fabs(a_r) > 100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				if (area_ < 0.00001)
				{
					area_ = 0.00001;
				}
				int devi_valence = nighbors_edge.size() - 6;
				aspect_ratio *= fmath::expd((double)(devi_valence*devi_valence));
				//		 aspect_ratio  *= std::exp((double)nighbors_edge.size());
				//				double c = aspect_ratio/(1.0 + fabs(2.0*3.14159 - gauss_c)/(area_/3.0));
				double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost, *e_it) = c;
				e.ecost = c; e.idx = *e_it;
				epq.push(e);
			}
			m.property(is_cal_he, *e_it) = true;
		}
	}
}

void HierarchicalSphereParametrization::Update_Halfedge_Cost_pengchao(Mesh &m, int i)
{
	EdgeInfo_ e;
	Mesh::VertexHandle v_it = m.vertex_handle(i);
	for (auto e_it = m.voh_iter(v_it); e_it.is_valid(); ++e_it)
	{
		if (!m.property(is_cal_he, *e_it))
		{
			//cout << m.property(is_cal_he, e_it) << endl;
			if (!m.is_collapse_ok(*e_it))
			{
				m.property(ecost, *e_it) = maxmum;
				//			e.idx = e_it.handle(); e.ecost = maxmum;
				//			epq.push(e);
			}
			else
			{
				Mesh::VertexHandle v_f = m.from_vertex_handle(*e_it);
				Mesh::VertexHandle v_t = m.to_vertex_handle(*e_it);
				Mesh::FaceHandle f1 = m.face_handle(*e_it), f2 = m.face_handle(m.opposite_halfedge_handle(*e_it));
				std::vector<std::vector<Mesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
				double gauss_c = 0, area_ = 0;
				for (auto he_it = m.voh_iter(v_f); he_it.is_valid(); ++he_it)
				{
					Mesh::HalfedgeHandle h0 = m.next_halfedge_handle(*he_it);
					Mesh::HalfedgeHandle h1 = m.prev_halfedge_handle(*he_it);
					Mesh::HalfedgeHandle h2 = *he_it;
					Mesh::Point p1 = m.point(m.to_vertex_handle(h2));
					Mesh::Point p2 = m.point(m.to_vertex_handle(h0));
					Mesh::Point p0 = m.point(m.to_vertex_handle(h1));
					double t = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
					double theta = acos(t);
					if (t < -0.9999)
					{
						theta = 3.14159;
					}
					if (t > 0.9999)
					{
						theta = 0.0;
					}
					gauss_c += theta;
					t = ((p1 - p0) % (p2 - p0)).norm() / 2.0;
					area_ += t;
					Mesh::FaceHandle f = m.face_handle(*he_it);
					if ((f != f1) && (f != f2))
					{
						std::vector<Mesh::Point> mid_e(2);
						mid_e[0] = p1;
						mid_e[1] = p2;
						nighbors_edge.push_back(mid_e);
					}
				}

				for (auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((*fv_it != f1) && (*fv_it != f2))
					{
						std::vector<Mesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(*fv_it); f_v != m.fv_end(*fv_it); ++f_v)
						{
							if (*f_v != v_t)
							{
								Mesh::Point p = m.point(*f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					Mesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
					if (fabs(a_r) > 100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				//		aspect_ratio *= nighbors_edge.size();
				//int devi_valence = nighbors_edge.size() - 6;
				//aspect_ratio *= fmath::expd((double)(devi_valence*devi_valence));
				//		 aspect_ratio  *= std::exp((double)nighbors_edge.size());
				if (area_ < 0.00001)
				{
					area_ = 0.00001;
				}
				double c = aspect_ratio / (1.0 + (2.0*3.14159 - gauss_c) / (area_ / 3.0));
				if (fabs(1.0 + (2.0*3.14159 - gauss_c) / (area_ / 3.0)) < 1e-10)
				{
					c = maxmum;
				}
				//double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost, *e_it) = c;
				e.ecost = c; e.idx = *e_it;
				epq_p.push(e);
			}
			m.property(is_cal_he, *e_it) = true;
		}
	}

	for (auto e_it = m.vih_iter(v_it); e_it.is_valid(); ++e_it)
	{
		if (!m.property(is_cal_he, *e_it))
		{
			//cout << m.property(is_cal_he, e_it) << endl;
			if (!m.is_collapse_ok(*e_it))
			{
				m.property(ecost, *e_it) = maxmum;
			}
			else
			{
				Mesh::VertexHandle v_f = m.from_vertex_handle(*e_it);
				Mesh::VertexHandle v_t = m.to_vertex_handle(*e_it);
				Mesh::FaceHandle f1 = m.face_handle(*e_it), f2 = m.face_handle(m.opposite_halfedge_handle(*e_it));
				std::vector<std::vector<Mesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
				double gauss_c = 0, area_ = 0;
				for (auto he_it = m.voh_iter(v_f); he_it.is_valid(); ++he_it)
				{
					Mesh::HalfedgeHandle h0 = m.next_halfedge_handle(*he_it);
					Mesh::HalfedgeHandle h1 = m.prev_halfedge_handle(*he_it);
					Mesh::HalfedgeHandle h2 = *he_it;
					Mesh::Point p1 = m.point(m.to_vertex_handle(h2));
					Mesh::Point p2 = m.point(m.to_vertex_handle(h0));
					Mesh::Point p0 = m.point(m.to_vertex_handle(h1));
					double t = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
					double theta = acos(t);
					if (t < -0.9999)
					{
						theta = 3.14159;
					}
					if (t > 0.9999)
					{
						theta = 0.0;
					}
					gauss_c += theta;
					t = ((p1 - p0) % (p2 - p0)).norm() / 2.0;
					area_ += t;
					Mesh::FaceHandle f = m.face_handle(*he_it);
					if ((f != f1) && (f != f2))
					{
						std::vector<Mesh::Point> mid_e(2);
						mid_e[0] = p1;
						mid_e[1] = p2;
						nighbors_edge.push_back(mid_e);
					}
				}

				for (auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((*fv_it != f1) && (*fv_it != f2))
					{
						std::vector<Mesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(*fv_it); f_v != m.fv_end(*fv_it); ++f_v)
						{
							if (*f_v != v_t)
							{
								Mesh::Point p = m.point(*f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					Mesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
					if (fabs(a_r) > 100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				if (area_ < 0.00001)
				{
					area_ = 0.00001;
				}
				//int devi_valence = nighbors_edge.size() - 6;
				//aspect_ratio *= fmath::expd((double)(devi_valence*devi_valence));
				//		 aspect_ratio  *= std::exp((double)nighbors_edge.size());
				double c = aspect_ratio / (1.0 + (2.0*3.14159 - gauss_c) / (area_ / 3.0));
				if (fabs(1.0 + (2.0*3.14159 - gauss_c) / (area_ / 3.0)) < 1e-10)
				{
					c = maxmum;
				}
				//double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost, *e_it) = c;
				e.ecost = c; e.idx = *e_it;
				epq_p.push(e);
			}
			m.property(is_cal_he, *e_it) = true;
		}
	}
}

double HierarchicalSphereParametrization::ComputeSphereRadius(Mesh &m)
{
	double s = 0.0;
	for (auto f_it = m.faces_begin(); f_it != m.faces_end(); ++f_it)
	{
		// ��ȡ��ǰ�����������
		std::vector<Mesh::Point> vs;
		for (auto fv_it = m.fv_begin(*f_it); fv_it != m.fv_end(*f_it); ++fv_it)
		{
			vs.push_back(m.point(*fv_it));
		}
		assert(vs.size() == 3 && "The mesh isn't triangular mesh!");

		s = s + 0.5*((vs[0] - vs[1]) % (vs[0] - vs[2])).norm();
	}
	return sqrt(s / (4.0*3.14159));
}

void HierarchicalSphereParametrization::Subdivision(int num_optimization_, std::vector<std::vector<int>> &idx_v_to_v)
{
	if ((origin_mesh.n_vertices() != 4) && (!is_in_sphere))
	{
		std::cout << " not a tetrahedron !" << std::endl;
	}
	else
	{
		// �����ĸ����㰴��ԭ����ķ���ͶӰ���뾶Ϊ radius ��������
		if (origin_mesh.n_vertices() == 4)
		{
			Compute_idx_to_idx_corresponding(origin_mesh);
			is_in_sphere = true;
			Mesh::Point p0(1.0, 0.0, 0.0);
			Mesh::Point p1(0.0, 1.0, 0.0);
			Mesh::Point p2(0.0, 0.0, 1.0);
			Mesh::Point p3(-1.0 / sqrt(3.0), -1.0 / sqrt(3.0), -1.0 / sqrt(3.0));
			origin_mesh.set_point(origin_mesh.vertex_handle(0), p0);
			origin_mesh.set_point(origin_mesh.vertex_handle(1), p1);
			origin_mesh.set_point(origin_mesh.vertex_handle(2), p2);
			origin_mesh.set_point(origin_mesh.vertex_handle(3), p3);
			std::vector<Mesh::Point> vf0;
			std::vector<int> idx_vf0;
			for (auto v_f = origin_mesh.fv_begin(origin_mesh.face_handle(0)); v_f != origin_mesh.fv_end(origin_mesh.face_handle(0)); ++v_f)
			{
				vf0.push_back(origin_mesh.point(*v_f));
				idx_vf0.push_back(v_f->idx());
			}
			if ((idx_vf0[0] != 0) && (idx_vf0[1] != 0) && (idx_vf0[2] != 0))
			{
				Mesh::Point mid_p0 = origin_mesh.point(origin_mesh.vertex_handle(0)) - vf0[0];
				Mesh::Point mid_p1 = vf0[1] - vf0[0];
				Mesh::Point mid_p2 = vf0[2] - vf0[1];
				if ((double)((mid_p1%mid_p2) | mid_p0) > 1e-10)
				{
					origin_mesh.set_point(origin_mesh.vertex_handle(0), -p0);
					origin_mesh.set_point(origin_mesh.vertex_handle(1), -p1);
					origin_mesh.set_point(origin_mesh.vertex_handle(2), -p2);
					origin_mesh.set_point(origin_mesh.vertex_handle(3), -p3);
				}
			}
			else if ((idx_vf0[0] != 1) && (idx_vf0[1] != 1) && (idx_vf0[2] != 1))
			{
				Mesh::Point mid_p0 = origin_mesh.point(origin_mesh.vertex_handle(1)) - vf0[0];
				Mesh::Point mid_p1 = vf0[1] - vf0[0];
				Mesh::Point mid_p2 = vf0[2] - vf0[1];
				if ((double)((mid_p1%mid_p2) | mid_p0) > 1e-10)
				{
					origin_mesh.set_point(origin_mesh.vertex_handle(0), -p0);
					origin_mesh.set_point(origin_mesh.vertex_handle(1), -p1);
					origin_mesh.set_point(origin_mesh.vertex_handle(2), -p2);
					origin_mesh.set_point(origin_mesh.vertex_handle(3), -p3);
				}
			}
			else if ((idx_vf0[0] != 2) && (idx_vf0[1] != 2) && (idx_vf0[2] != 2))
			{
				Mesh::Point mid_p0 = origin_mesh.point(origin_mesh.vertex_handle(2)) - vf0[0];
				Mesh::Point mid_p1 = vf0[1] - vf0[0];
				Mesh::Point mid_p2 = vf0[2] - vf0[1];
				if ((double)((mid_p1%mid_p2) | mid_p0) > 1e-10)
				{
					origin_mesh.set_point(origin_mesh.vertex_handle(0), -p0);
					origin_mesh.set_point(origin_mesh.vertex_handle(1), -p1);
					origin_mesh.set_point(origin_mesh.vertex_handle(2), -p2);
					origin_mesh.set_point(origin_mesh.vertex_handle(3), -p3);
				}
			}
			else if ((idx_vf0[0] != 3) && (idx_vf0[1] != 3) && (idx_vf0[2] != 3))
			{
				Mesh::Point mid_p0 = origin_mesh.point(origin_mesh.vertex_handle(3)) - vf0[0];
				Mesh::Point mid_p1 = vf0[1] - vf0[0];
				Mesh::Point mid_p2 = vf0[2] - vf0[1];
				if ((double)((mid_p1%mid_p2) | mid_p0) > 1e-10)
				{
					origin_mesh.set_point(origin_mesh.vertex_handle(0), -p0);
					origin_mesh.set_point(origin_mesh.vertex_handle(1), -p1);
					origin_mesh.set_point(origin_mesh.vertex_handle(2), -p2);
					origin_mesh.set_point(origin_mesh.vertex_handle(3), -p3);
				}
			}

			//bcd_optimization = new BCD_Sphere_Optimization();
			//string s = to_string(current_num_v);
			//bcd_optimization->PrintObj(s + "_sub", &origin_mesh);
			//delete bcd_optimization;

		}
		global_max_energy = 5.0;
		int counter = 0;
		int current_iter = 0;
		int opt_mun = 0; double s = 0.1;
		while (current_num_v < n_vertices)
		{
			if (!idx_v_to_v.size())
			{
				break;
			}
			bool is_restored = Restore_Last_mesh(origin_mesh, idx_v_to_v.back());
			idx_v_to_v.pop_back();
			counter++;
			current_num_v++;
			if (!is_restored)
			{
				std::cout << "restore faild !" << std::endl;
				break;
			}
			current_iter++;
			/*if (current_iter == num_optimization_)
			{
			bcd_v_optimization->SetMesh(&origin_mesh);
			bcd_v_optimization->optimize_sphere_volume(s, 20);
			global_max_energy = bcd_v_optimization->max_iso_distortion();
			int iter_count = 0;
			if (global_max_energy > 40)
			{

			while (global_max_energy > 40 && iter_count < 3)
			{
			++iter_count;
			bcd_v_optimization->optimize_sphere_volume(s, 20);
			global_max_energy = bcd_v_optimization->max_iso_distortion();
			}
			}
			current_iter = 0;
			}*/

			//cout << current_num_v<< endl;
			// optimize with area + mips
			/*bcd_optimization = new BCD_Sphere_Optimization(&origin_mesh,1.0);
			Mesh::VertexHandle v = origin_mesh.vertex_handle(origin_mesh.n_vertices()-1);
			double max_l = bcd_optimization->ComputeLocalMaxTriangleDistortion(&origin_mesh,0.5,v);
			if ((max_l > 50))
			{
			bcd_optimization->prepare_parameterization(bcd_optimization->mesh);
			bcd_optimization->do_EXP_parameterizing(1.0,0.5,20);
			global_max_energy = bcd_optimization->ComputeGlobalMaxTriangleDistortion(&origin_mesh,0.5);
			int iter_count = 0;
			if (global_max_energy > 40)
			{

			while (global_max_energy > 40 && iter_count < 3)
			{
			++iter_count;
			bcd_optimization->do_EXP_parameterizing(1.0, 0.5, 20);
			global_max_energy = bcd_optimization->ComputeGlobalMaxTriangleDistortion(&origin_mesh, 0.5);
			}
			}
			delete  bcd_optimization;
			bcd_optimization = NULL;
			record_max_dis.push_back(global_max_energy);
			recore_add_v_nun.push_back(current_iter);
			current_iter = 0;
			opt_mun++;
			}*/

			if (counter < 10 && counter > 3)
			{
				bcd_v_optimization->SetMesh(&origin_mesh);
				bcd_v_optimization->optimize_sphere_volume(s, 10);
			}

			bcd_v_optimization->SetMesh(&origin_mesh);
			Mesh::VertexHandle v = origin_mesh.vertex_handle(origin_mesh.n_vertices() - 1);
			double max_iso_d = bcd_v_optimization->max_iso_local_distortion(v, 1.0);
			//if ((max_iso_d > std::min((10.0*global_max_energy), 40.0)) || (current_iter > 100))
			if (max_iso_d > 50)
			{
				/*bcd_optimization = new BCD_Sphere_Optimization();
				string f = to_string(current_num_v);
				bcd_optimization->PrintObj(f + "_before_op", &origin_mesh);*/

				if (current_num_v > 20000)
				{
					bcd_v_optimization->optimize_sphere_volume(s, 20);
				}
				else
				{
					bcd_v_optimization->optimize_sphere_volume(s, 20);
				}

				//bcd_v_optimization->optimize_sphere_volume(s, 20);
				global_max_energy = bcd_v_optimization->max_iso_distortion();
				int iter_count = 0;
				if (global_max_energy > 40)
				{

					while (global_max_energy > 40 && iter_count < 3)
					{
						++iter_count;
						bcd_v_optimization->optimize_sphere_volume(s, 20);
						global_max_energy = bcd_v_optimization->max_iso_distortion();
					}
				}
				/*int iter_count = 0;
				if (global_max_energy > 40)
				{
				while (global_max_energy > 40 && iter_count < 3)
				{
				s *= 0.15; ++iter_count;
				bcd_v_optimization->optimize_sphere_volume(s, 50);
				global_max_energy = bcd_v_optimization->max_iso_distortion();
				}
				}
				else if (global_max_energy < 20)
				{
				s = 0.1;
				}*/
				//delete  bcd_v_optimization;
				//bcd_v_optimization = NULL;
				record_max_dis.push_back(global_max_energy);
				//recore_add_v_nun.push_back(current_iter);
				recore_add_v_nun.push_back(current_num_v);
				current_iter = 0;
				opt_mun++;

				/*bcd_optimization->PrintObj(f + "_after_op", &origin_mesh);
				delete bcd_optimization;*/
				//bcd_optimization = new BCD_Sphere_Optimization();
				//string s = to_string(current_num_v);
				//bcd_optimization->PrintObj(s, &origin_mesh);
				//delete bcd_optimization;
			}
			/*if (counter%10 == 0)
			{
			bcd_optimization = new BCD_Sphere_Optimization();
			string s = to_string(current_num_v);
			bcd_optimization->PrintObj(s+"_", &origin_mesh);
			delete bcd_optimization;
			}*/
			if (current_num_v % 1000 == 0)
			{
				std::cout << "current vertex number : " << current_num_v << std::endl;
			}
		}
		std::cout << "opt num: " << opt_mun << std::endl;
		if (current_num_v == n_vertices)
		{
			nei_ps1.clear();
			std::cout << "subdivision success !" << std::endl;
			//bcd_v_optimization = new BCD_Volume_Sphere_Optimization();
			//bcd_v_optimization->SetThreshhold(1e-8, 1e-8);
			bcd_v_optimization->SetMesh(&origin_mesh);
			bcd_v_optimization->optimize_sphere_volume(s, 200);
			bcd_v_optimization->compute_distortion();
			//delete  bcd_v_optimization;
			//bcd_v_optimization = NULL;
			bool is_overlap = bcd_v_optimization->checklap(&origin_mesh, 1e-12);
			if (is_overlap)
			{
				std::cout << "the result have overlap" << std::endl;
			}
			else
			{
				std::cout << "the result do not have overlap" << std::endl;
			}

			for (auto it = origin_mesh.vertices_begin(); it != origin_mesh.vertices_end(); ++it)
			{
				int i = origin_mesh.property(vindex, *it);
				Mesh::Point p = origin_mesh.point(*it);
				copy_origin_mesh.set_point(copy_origin_mesh.vertex_handle(i), p);
			}
			origin_mesh = copy_origin_mesh;

			//bcd_optimization = new BCD_Sphere_Optimization();
			//string f = to_string(current_num_v);
			//bcd_optimization->PrintObj(f + "_final", &origin_mesh);
			//delete bcd_optimization;

			for (auto v_it = origin_mesh.vertices_begin(); v_it != origin_mesh.vertices_end(); ++v_it)
			{
				Mesh::Point p = radius*origin_mesh.point(*v_it);
				origin_mesh.set_point(*v_it, p);
			}

			//std::cout <<"sphere para is success !!!!!!" << std::endl;
			bcd_optimization = new BCD_Sphere_Optimization(&origin_mesh, &copy_origin_mesh1, radius);
			bcd_optimization->triangle_distortion(&origin_mesh, &copy_origin_mesh1);
			bcd_optimization->prepare_parameterization();
			//std::cout << "prepare is success !!!!!!" << std::endl;
			/*bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);*/
			bcd_optimization->do_parallel_parameterizing(0.0, 400);
			bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.0, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.0, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.0, 50);
			bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.0, 50);
			//bcd_optimization->do_parallel_parameterizing(0.0, 100);
			//bcd_optimization->do_parallel_parameterizing(0.0, 100);
			delete  bcd_optimization;
			bcd_optimization = NULL;
			//std::cout << "optimize is success !!!!!!" << std::endl;
		}
	}
	return;
}

void HierarchicalSphereParametrization::Compute_idx_to_idx_corresponding(Mesh &m)
{
	idx_to_idx_corresponding.resize(n_vertices);
	int nv = m.n_vertices();
	int c = index_collapse_v_to_v.size();
	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		idx_to_idx_corresponding[m.property(vindex, *v_it)] = v_it->idx();
	}
	for (int i = 0; i < c; i++)
	{
		idx_to_idx_corresponding[index_collapse_v_to_v[c - 1 - i][0]] = nv + i;
	}
}

Mesh::VertexHandle HierarchicalSphereParametrization::ComputeBihedralAngles(const Mesh &m, const Mesh::VertexHandle &idx)
{
	Mesh::VertexHandle vh;
	double da = -5.0;
	for (const auto & heh : m.voh_range(idx))
	{
		double mid = m.calc_dihedral_angle(heh);
		if (da < mid)
		{
			vh = m.to_vertex_handle(heh);
			da = mid;
		}
	}
	return vh;
}

bool HierarchicalSphereParametrization::OptimizeOneRing(Mesh &m, const Mesh::VertexHandle &idx, Mesh::VertexHandle v_t, int c)
{
	Mesh::VertexHandle v_id = ComputeBihedralAngles(m, idx);
	//	vector<vector<Mesh::Point>> nei_in_sphere;
	//	vector<Mesh::Point> mid(2);
	std::vector<Mesh::Point> nei_eh_in_sphere; nei_eh_in_sphere.reserve(16);
	std::vector<Mesh::Point> n_p_cross; n_p_cross.reserve(16);
	std::vector<Mesh::Point> centroid_of_t; centroid_of_t.reserve(16);
	Mesh::Point p0 = m.point(v_id);
	for (auto he_it = m.voh_iter(v_id); he_it.is_valid(); ++he_it)
	{
		Mesh::VertexHandle v1 = m.to_vertex_handle(*he_it);

		Mesh::VertexHandle v2 = m.to_vertex_handle(m.next_halfedge_handle(*he_it));

		if ((v1 != idx) && (v2 != idx))
		{
			Mesh::Point p1 = m.point(v1);
			Mesh::Point p2 = m.point(v2);
			Mesh::Point c = (p1 + p2 + p0) / 3.0;
			c = c / c.norm();
			centroid_of_t.push_back(c);
			Mesh::Point cross_p1_p2 = p1%p2;
			n_p_cross.push_back(cross_p1_p2);
			nei_eh_in_sphere.push_back((p0 + p1) / (p0 + p1).norm());
			//			mid[0] = p1;
			//			mid[1] = p2;
			//			nei_in_sphere.push_back(mid);
		}
	}
	bool is_update = false;
	for (int i = 0; i < centroid_of_t.size(); i++)
	{
		bool sig = local_check_negative_area(centroid_of_t[i], n_p_cross);
		if (sig)
		{
			is_update = true;
			m.set_point(v_id, centroid_of_t[i]);
			bool is_add_ok = Add_One_Point(m, idx, v_t, c);
			if (is_add_ok)
			{
				return true;
			}
		}
	}
	if (!is_update)
	{
		for (int i = 0; i < nei_eh_in_sphere.size(); i++)
		{
			bool sig = local_check_negative_area(nei_eh_in_sphere[i], n_p_cross);
			if (sig)
			{
				m.set_point(v_id, nei_eh_in_sphere[i]);
				bool is_add_ok = Add_One_Point(m, idx, v_t, c);
				if (is_add_ok)
				{
					return true;
				}
			}
		}
	}
	return false;
}

void HierarchicalSphereParametrization::PrintInfo(std::string fileName)
{
	std::ofstream ofs(fileName + ".txt");
	if (!ofs.is_open())
	{
		return;
	}
	for (const auto &v : recore_add_v_nun)
	{
		ofs << v << std::endl;
	}
	ofs.close();
}

void HierarchicalSphereParametrization::RefineModel(Mesh &m, double thresh_hold, double r)
{
	double min_ratio = 2;
	double l = 0.0;
	double ra = r*r;
	for (auto e_it = m.edges_begin(); e_it != m.edges_end(); ++e_it)
	{
		l = 0.25*m.calc_edge_sqr_length(*e_it);
		l = std::sqrt(ra - l);
		if (min_ratio > l / r)
		{
			min_ratio = l / r;
		}
	}

	int iter = 0;
	Mesh::EIter     e_it, e_end;
	while (min_ratio < thresh_hold)
	{
		//for (auto e_it = m.edges_begin(); e_it != m.edges_end(); ++e_it)
		for (e_it = m.edges_begin(), e_end = m.edges_end(); e_it != e_end; ++e_it)
		{
			l = 0.25*m.calc_edge_sqr_length(*e_it);
			l = std::sqrt(ra - l);
			if (l / r < thresh_hold)
			{
				Mesh::HalfedgeHandle he = m.halfedge_handle(*e_it, 0);
				Mesh::Point p = (m.point(m.to_vertex_handle(he)) + m.point(m.from_vertex_handle(he))) / 2.0;
				p = r*p / p.norm();
				int idx_e = e_it->idx();
				int idx_v1 = (m.to_vertex_handle(he)).idx();
				int idx_v2 = (m.to_vertex_handle(m.opposite_halfedge_handle(he))).idx();
				//cout << idx_v1 << " " << idx_v2 << " " << copy_origin_mesh1.to_vertex_handle(copy_origin_mesh1.halfedge_handle(copy_origin_mesh1.edge_handle(idx_e), 0)).idx() << " " << copy_origin_mesh1.to_vertex_handle(copy_origin_mesh1.halfedge_handle(copy_origin_mesh1.edge_handle(idx_e), 1)).idx() << endl;
				Mesh::Point o_p = 0.5*(copy_origin_mesh1.point(copy_origin_mesh1.vertex_handle(idx_v1)) + copy_origin_mesh1.point(copy_origin_mesh1.vertex_handle(idx_v2)));
				m.split(*e_it, p);
				copy_origin_mesh1.split(copy_origin_mesh1.edge_handle(idx_e), o_p);
			}
		}
		iter++;
		std::cout << iter << std::endl;
		bcd_optimization = new BCD_Sphere_Optimization(&m, &copy_origin_mesh1, r);
		bcd_optimization->prepare_parameterization();
		bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.5, 100);
		delete  bcd_optimization;
		bcd_optimization = NULL;

		min_ratio = 2;
		//for (auto e_it = m.edges_begin(); e_it != m.edges_end(); ++e_it)
		for (e_it = m.edges_begin(), e_end = m.edges_end(); e_it != e_end; ++e_it)
		{
			l = 0.25*m.calc_edge_sqr_length(*e_it);
			l = std::sqrt(ra - l);
			if (min_ratio > l / r)
			{
				min_ratio = l / r;
			}
		}
	}
}