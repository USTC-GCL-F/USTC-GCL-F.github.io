#pragma once

#include "MeshDefinition.h"
#include "graph_coloring.h"
#include "fmath.hpp"
#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <Eigen/Dense>
#include <Eigen/SparseQR>
#include <omp.h>

class BCD_Sphere_Optimization
{
public:
	BCD_Sphere_Optimization(void);
	BCD_Sphere_Optimization(Mesh *m, const Mesh *m1,double radius_);
	BCD_Sphere_Optimization(Mesh* m,double radius_);
	BCD_Sphere_Optimization(Mesh* m,double radius_,OpenMesh::VPropHandleT<Mesh::Point> &origin_position);
	~BCD_Sphere_Optimization(void);

public:
	void prepare_parameterization();
	void prepare_parameterization(Mesh* mesh_);
	void origin_prepare_parameterization(Mesh* mesh_,OpenMesh::VPropHandleT<Mesh::Point> &origin_position_);
	void do_parameterizing(double energy_power, double angle_area_ratio,int iter);
	void do_EXP_parameterizing(double energy_power, double angle_area_ratio,int iter);
	void do_parallel_EXP_parameterizing(double energy_power, double angle_area_ratio, int iter);
	void do_parallel_parameterizing(double angle_area_ratio, int iter);
	void do_Refine_EXP_parameterizing(double energy_power, double angle_area_ratio, int iter);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  mips + area
	void MIPS_AREA_Reposition(Mesh* mesh_, double step_length, double angle_area_ratio);
	void EXP_MIPS_AREA_Reposition(Mesh* mesh_, double step_length, double energy_power, double angle_area_ratio);
	bool local_check_negative_area_SUV(const int& vv_size, const double& npx, const double& npy, const double& npz, 
		const std::vector<double>& p1_p2_cross_x, const std::vector<double>& p1_p2_cross_y, const std::vector<double>& p1_p2_cross_z);
	void EXP_MIPS_AREA_Reposition_one_V(int i, double step_length, double energy_power, double angle_area_ratio,
		std::vector<double>& l0_n_vec,
		std::vector<double>& p1_vec_x, std::vector<double>& p1_vec_y, std::vector<double>& p1_vec_z,
		std::vector<double>& p2_vec_x, std::vector<double>& p2_vec_y, std::vector<double>& p2_vec_z,
		std::vector<double>& p1_p2_cross_x, std::vector<double>& p1_p2_cross_y, std::vector<double>& p1_p2_cross_z);

	void MIPS_AREA_Reposition_one_V(int i, double step_length, double angle_area_ratio,
		std::vector<double>& l0_n_vec,
		std::vector<double>& p1_vec_x, std::vector<double>& p1_vec_y, std::vector<double>& p1_vec_z,
		std::vector<double>& p2_vec_x, std::vector<double>& p2_vec_y, std::vector<double>& p2_vec_z,
		std::vector<double>& p1_p2_cross_x, std::vector<double>& p1_p2_cross_y, std::vector<double>& p1_p2_cross_z);

	bool compute_local_MIPS_AREA_energy(double& new_e, const double& old_e, const int& vv_size,
		const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec);
	bool compute_local_EXP_MIPS_AREA_energy(double& new_e, const double& old_e, const int& vv_size, const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec);

	void PrintObj(std::string fileName, Mesh *m);
	double ComputeAngle(Eigen::Vector3d v1,Eigen::Vector3d v2);
	void save_graph(const char* filename);
	void load_vertex_color(const char* filename);
	void ComputeOriginTrangleArea();
	bool compute_local_ISOMETRIC_energy(double& new_e, const double& old_e, const int& vv_size,
		const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec);
	bool compute_local_MIPS_energy(double& new_e, const double& old_e, const int& vv_size,
		const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec);  // conformal energy 
	double ComputeNewRadius();
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	bool checklap(Mesh* mesh_,double threh);
//	void CalculateFlatten_x();
//	void CalculateFlatten_u();
//	void DistortionCompute();
//	void ComputeColorMap();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// mips + vol
	void MIPS_VOL_Reposition(Mesh* mesh_, double step_length, double angle_area_ratio);
	bool compute_local_MIPS_VOL_energy(double& new_e, const double& old_e, const int& vv_size,
		const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_vol_vec, const std::vector<double>& inv_fh_vol_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec,
		const std::vector<double>& p1_p2_cross_x, const std::vector<double>& p1_p2_cross_y, const std::vector<double>& p1_p2_cross_z);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
	bool Judge_local_distortion_v(Mesh::VertexHandle &v,int threshold);
	void Local_EXP_MIPS_AREA_Reposition_v(Mesh::VertexHandle &v, double energy_power, double angle_area_ratio);
	std::vector<Eigen::VectorXf> ComputeTriangleDistortion(Mesh* mesh_, double angle_area_ratio);
	std::vector<Eigen::VectorXf> ComputeTriangleDistortion_Refer_Originmesh(Mesh* mesh_, Mesh* m1, double angle_area_ratio);
	double ComputeLocalMaxTriangleDistortion_Refer_Originmesh(Mesh* mesh_, Mesh* m1, double angle_area_ratio, Mesh::VertexHandle &v);
	double ComputeMaxTriangleDistortion_Refer_Originmesh(const Mesh* mesh_, const Mesh* m1, double angle_area_ratio);
	double ComputeGlobalMaxTriangleDistortion(Mesh* mesh_,double angle_area_ratio); 
	double ComputeLocalMaxTriangleDistortion(Mesh* mesh_,double angle_area_ratio,Mesh::VertexHandle &v);
	std::vector<Eigen::VectorXf> triangle_distortion(const Mesh * mesh_, const Mesh * m1);
	void scale_by_isometric();
	void Compute_origin_area();
public:
	Mesh *mesh;
	const Mesh *origin_mesh;
//	int iter;
private:
	double radius_suv;
	double dr_eps;
	double overlap_eps;
private:
	std::vector<double> new_p_x; std::vector<double> new_p_y; std::vector<double> new_p_z;
	std::vector<std::vector<int>> vertex_v1; std::vector<std::vector<int>> vertex_v2;
	std::vector<std::vector<double>> omega0; std::vector<std::vector<double>> omega1; std::vector<std::vector<double>> omega2;
	std::vector<std::vector<double>> face_area; std::vector<std::vector<double>> inv_face_area;
	std::vector<std::vector<double>> face_vol; std::vector<std::vector<double>> inv_face_vol; 
	std::vector<double> vertex_radius_ratio; int max_vv_size;
	int number_of_color;
	std::vector< std::vector<int> > vertex_diff_color;
	int max_vertex_color;
	OpenMesh::VPropHandleT<Mesh::Point> origin_position_;

	/////////////////////////////////////////////////////////////
	std::vector<double> p1_nei_x, p1_nei_y, p1_nei_z, p2_nei_x, p2_nei_y, p2_nei_z;
	double cot_angla,fa_area;
	double current_x,current_y,current_z;
	int size_nei;
	std::vector<double> origin_mesh_area;
	/////////////////////////////////////////////////////////////// subdivision of sphere triangle
	fmath::PowGenerator *f;
	double high_d;
	double thresh_hold;
	std::vector<std::vector<std::vector<std::vector<double>>>> all_sub_triangle;
	std::vector<std::vector<std::vector<double>>> sub_triangles;
	std::vector<std::vector<double>> record_start_point;
	std::vector<int> num_sun_nei;
	double ComputeRefineAmipsEreaEnergy(int &k, double &angle_area_ratio, double &px, double &py, double &pz, std::vector<int> &vv1, std::vector<int> &vv2);
	bool JudgeRefineAmipsEreaEnergy(double old_e, int &k, double &angle_area_ratio, double &px, double &py, double &pz, std::vector<int> &vv1, std::vector<int> &vv2);
	void FindAllSubTriangles(double t1,double t2,double t3); // p0 = (n,0,0); p1 = (0,n,0); p2 = (0,0,n) 
	double ComputeSubTriangleEnergy(int &n,double &angle_area_ratio,Mesh::Point &p_0,Mesh::Point &p_1,Mesh::Point &p_2);
	void Refine_EXP_MIPS_AREA_Reposition(Mesh* mesh_, double step_length, double energy_power, double angle_area_ratio);
	void prepare_refine();
};

