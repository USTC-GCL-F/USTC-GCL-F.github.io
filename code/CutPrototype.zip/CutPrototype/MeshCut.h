#ifndef MESHCUT_H
#define MESHCUT_H

#include "MeshDefinition.h"
#include <OpenMesh/Tools/Smoother/JacobiLaplaceSmootherT.hh>
#include <OpenMesh/Tools/Smoother/SmootherT.hh>
#include <iostream>
#include <fstream>
#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <Eigen/Dense>
#include <Eigen/SparseQR>

class MeshCut
{
public:
	MeshCut();
	void set_mesh(const Mesh& mesh_);
	void mesh_cut(std::vector<int> & boundary_point, std::string file_name, bool is_order);
	~MeshCut();

	std::vector<int> he_to_idx;
	std::vector<int> idx_to_mesh_idx;

	int big_valance_point_number;
	int boundary_number;
	std::vector<int> candidate_seam_vertex;//�洢�����ϵĵ��Ƿ��ڱ߽��ϣ�true��ʾ�ڱ߽���
	std::vector<int> boundary_points;//�洢�����ڱ߽�·���ϵĵ������
	std::vector<int> big_v;
	std::vector<double> f_dis;
	std::vector<double> f_gauss_curvature;
	std::vector<double> stretch_dis;

	//add by hu xin 
	Mesh mesh_ref();
	Mesh cuted_mesh;
	Mesh copy_cut_mesh;
	std::vector<std::vector<double>>get_weight_of_matrix(Mesh & para_mesh, std::vector<double>& metric_, std::vector<int> boundary_p);
	void prepare_compute_distortion();
	void compute_all_triangle_dis(const Mesh & para_mesh, double angle_area_ratio);
	int find_largest_distortion_v(double thresh_hold);
	int find_largest_curvature_v(std::vector<int> & sig);
	void add_new_boundary_points(std::vector<int>& a);
	std::vector<int> find_new_boundary(int update_l, std::vector<double>& metric_);
	std::vector<int> remove_selected_boundary(std::vector<int> & selected_b);
	void set_edge_signal(std::vector<int> & e);

	void calc_gauss_curvature(Mesh &mesh_);
	Mesh update_cut_mesh_position(Mesh & para_mesh);

	void saparate_new_seam(Mesh & para_mesh, std::vector<int> new_seam);
	bool local_check_negative_area(Mesh::Point &p, std::vector<Mesh::Point> &n_p1, std::vector<Mesh::Point> &n_p2); // �ж��Ƿ����Խ�
	double local_isotropy_energy(Mesh::Point &p, std::vector<Mesh::Point> &np1, std::vector<Mesh::Point> &np2);

	std::vector<double> get_triangle_distortion();
	std::vector<int> find_selected_idx_of_v(Mesh& para_mesh, std::vector<int> & find_p);
	// find high curvature points
	std::vector<int> find_high_curvature_point(Mesh & m, double threshhold);

	void triangle_distortion(Mesh * mesh_, Mesh * m1);

	std::vector<OpenMesh::Vec3d> clustered_points(std::vector<OpenMesh::Vec3d>& date_set);
	void PersistenceClustering(const Mesh & mesh, const double & tau);
	void clustered_points_separate(const Mesh & para_mesh, std::vector<int>& date_set, double threshhold);
	std::vector<std::vector<int>> clustered_points_step(Mesh & para_mesh, const std::vector<int>& date_set, double threshhold);
	std::vector<int> fliter_tri_by_middle_num(std::vector<int>& date_set);
	std::vector<int> fliter_tri_by_average(std::vector<int>& date_set);
	void smoother();

	void get_two_bound_points(Mesh& m, std::vector<int>& bound_points_);

public:
	Mesh mesh;
	std::vector<int> candidate_cut_valence;//�洢�߽��ϵĵ�Ķ�
	std::vector<int> candidate_seam_edge;//�洢�����ϵı��Ƿ��ڱ߽��ϣ�ture��ʾ�ڱ߽���

	void Mark_Vertex_Edge();//��������ı߽�·�������洢�����ϵ�ͱߵ�״̬��Ϣ
	void Get_Valence();//��������ı߽�·���õ����ϵ�Ķ�

	//OpenMesh::FPropHandleT<double> f_dis;
	//OpenMesh::VPropHandleT<bool> is_boundary;
	std::vector<double> omega0;
	std::vector<double> omega1;
	std::vector<double> omega2;
	std::vector<double> face_area;
	std::vector<std::vector<double>> one_ring_weight;
	std::vector<int> is_boundary;

	std::vector<double> edge_weight;
	const double max = 1.0e30;

	std::vector<double> v_gausscurvature;
	std::vector<double> e_gauss_curvature;

public:
	std::vector<int> selected_tri_num;
	std::vector<int> selected_tri;
	std::vector<int> c_p_idx;
	std::vector<int> tri_idx;
	double max_stretch_d;
	int max_stretch_idx;
};

#endif // MESHCUT_H