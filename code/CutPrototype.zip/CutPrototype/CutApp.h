#pragma once
#include "MeshDefinition.h"
class CutApp
{
private:
	CutApp(void);
	~CutApp(void);
public:
	CutApp(CutApp const&) = delete;
	CutApp(CutApp &&) = delete;
	CutApp& operator=(CutApp const&) = delete;
	CutApp& operator=(CutApp &&) = delete;
	static CutApp& GetInstance(void);

	bool ParseCommand(int argc, char *argv[]);
	bool Run(void);
private:
	void PrintError(void);
	void CutMesh(void);

	Mesh mesh;
	Mesh orimesh;
	std::string meshfilename;
	std::string meshpath;
	std::string meshbasename;
	bool iscutorigin;
	bool isdospherical;
	std::string spherefilename;
};

