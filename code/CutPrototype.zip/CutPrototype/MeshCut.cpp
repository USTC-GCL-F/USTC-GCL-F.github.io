#include "MeshCut.h"
#include <set>
#include <list>

//#include "dataanalysis.h"
//#pragma comment(lib, "alglib.lib")
//using namespace alglib;

MeshCut::MeshCut()
{

}

MeshCut::~MeshCut()
{

}

void MeshCut::set_mesh(const Mesh &mesh_)
{
	mesh = mesh_;
	selected_tri.clear();
	selected_tri_num.clear();
	selected_tri.resize(mesh.n_faces(), 0);
	selected_tri_num.resize(mesh.n_faces(), 0);
	c_p_idx.clear();
	tri_idx.clear();
	//calc_gauss_curvature(mesh);
	//mesh.add_property(f_dis);
}

void MeshCut::smoother()
{
	OpenMesh::Smoother::JacobiLaplaceSmootherT<Mesh> smoother(mesh);
	smoother.initialize(smoother.Tangential, smoother.C1);   //Smooth direction Continuity
	smoother.smooth(20);
	smoother.initialize(smoother.Tangential_and_Normal, smoother.C1);
	smoother.smooth(1);
}

void MeshCut::mesh_cut(std::vector<int> & boundary_point, std::string file_name, bool is_order)
{
	boundary_points = boundary_point;
	if (is_order)
	{
		Mark_Vertex_Edge();
		Get_Valence();
	}
	else
	{
		//set_edge_signal(boundary_points);
		Get_Valence();
	}

	he_to_idx.clear();
	idx_to_mesh_idx.clear();
	he_to_idx.resize(mesh.n_halfedges());
	Mesh::HalfedgeHandle h_begin;

	Mesh::VertexHandle v_begin;
	for (int i = 0; i < candidate_seam_edge.size(); i++)
	{
		if (candidate_seam_edge[i])
		{
			h_begin = mesh.halfedge_handle(mesh.edge_handle(i), 0);
			break;
		}
	}
	std::cout << "initial halfedge idx: " << h_begin.idx() << std::endl;

	/*v_begin = mesh.vertex_handle(boundary_points[0]);
	for (auto halfedge = mesh.voh_iter(v_begin); halfedge; ++halfedge)
	{
	int halfedge_vertex = mesh.to_vertex_handle(halfedge).idx();
	if (halfedge_vertex == boundary_points[1])
	{
	h_begin = halfedge;
	}
	}*/

	/*for (auto e_h : mesh.edges())
	{
	if (!candidate_seam_edge[e_h.idx()])
	{
	continue;
	}
	h_begin = mesh.halfedge_handle(e_h, 0);
	if (mesh.is_boundary(h_begin) && mesh.from_vertex_handle(h_begin).idx() == boundary_points[0])
	{
	h_begin = mesh.halfedge_handle(e_h, 1);
	}
	}*/
	Mesh::HalfedgeHandle h_iter = h_begin;
	int uv_idx = 0;
	do
	{
		int h_idx = h_iter.idx();
		int v_idx = mesh.to_vertex_handle(h_iter).idx();
		he_to_idx[h_idx] = uv_idx;
		idx_to_mesh_idx.push_back(v_idx);
		h_iter = mesh.next_halfedge_handle(h_iter);
		while (!candidate_seam_edge[mesh.edge_handle(h_iter).idx()])
		{
			h_iter = mesh.opposite_halfedge_handle(h_iter);
			he_to_idx[h_iter.idx()] = uv_idx;
			h_iter = mesh.next_halfedge_handle(h_iter);
		}
		uv_idx++;
	} while (h_iter != h_begin);
	boundary_number = uv_idx;
	std::cout << "boundary_number: " << boundary_number << std::endl;
	for (auto v_h : mesh.vertices())
	{
		if (candidate_cut_valence[v_h.idx()] > 0)
		{
			continue;
		}
		int v_idx = v_h.idx();
		for (auto vih_iter : mesh.vih_range(v_h))
		{
			he_to_idx[vih_iter.idx()] = uv_idx;
		}
		idx_to_mesh_idx.push_back(v_idx);
		uv_idx++;
	}

	/*std::ofstream out(file_name);
	out.precision(DBL_DIG);

	for (size_t i = 0; i < uv_idx; i++)
	{
	out << "v " << mesh_.point(mesh_.vertex_handle(idx_to_mesh_idx[i])) << std::endl;
	}

	for (auto f_h : mesh_.faces())
	{
	out << "f";
	for (auto fh_iter : mesh_.fh_range(f_h))
	{
	out << " " << he_to_idx[fh_iter.idx()] + 1 << "/" << he_to_idx[fh_iter.idx()] + 1;
	}
	out << std::endl;
	}

	out.close();*/

	//add by huxin 
	cuted_mesh.clean();
	for (int i = 0; i < uv_idx; i++)
	{
		cuted_mesh.add_vertex(mesh.point(mesh.vertex_handle(idx_to_mesh_idx[i])));
	}
	std::vector<Mesh::VertexHandle> face_vhandles;
	for (auto f_h : mesh.faces())
	{
		face_vhandles.clear();
		for (auto fh_iter : mesh.fh_range(f_h))
		{
			face_vhandles.push_back(cuted_mesh.vertex_handle(he_to_idx[fh_iter.idx()]));
		}
		cuted_mesh.add_face(face_vhandles);
	}

	int counter = 0;
	for (int i = 0; i < candidate_seam_vertex.size(); i++)
	{
		if (candidate_seam_vertex[i])
		{
			counter++;
		}
	}
	std::cout << "number of boundary points:" << counter << std::endl;
	counter = 0;
	for (int i = 0; i < candidate_seam_edge.size(); i++)
	{
		if (candidate_seam_edge[i])
		{
			counter++;
		}
	}
	std::cout << "number of boundary edge:" << counter << std::endl;
	counter = 0;
	for (int i = 0; i < candidate_cut_valence.size(); i++)
	{
		if (candidate_cut_valence[i] == 1)
		{
			counter++;
		}
	}
	std::cout << "number of valence 1 points:" << counter << std::endl;
	for (int i = 0; i < candidate_cut_valence.size(); i++)
	{
		if (candidate_cut_valence[i] > 2)
		{
			std::cout << "high valence points: " << i << std::endl;
		}
	}
}

Mesh MeshCut::update_cut_mesh_position(Mesh & para_mesh)
{
	copy_cut_mesh = cuted_mesh;
	unsigned counter = 0;
	for (auto f_it = para_mesh.faces_begin(); f_it != para_mesh.faces_end(); ++f_it)
	{
		std::vector<Mesh::Point> mid;
		for (auto fv_it = para_mesh.fv_begin(*f_it); fv_it != para_mesh.fv_end(*f_it); ++fv_it)
		{
			mid.push_back(para_mesh.point(*fv_it));
		}

		Mesh::FaceHandle c_f_it = copy_cut_mesh.face_handle(counter);
		int c = 0;
		for (auto c_fv_it = copy_cut_mesh.fv_begin(c_f_it); c_fv_it != copy_cut_mesh.fv_end(c_f_it); ++c_fv_it)
		{
			copy_cut_mesh.set_point(*c_fv_it, mid[c]);
			c++;
		}
		counter++;
	}
	return copy_cut_mesh;
}

void MeshCut::saparate_new_seam(Mesh & para_mesh, std::vector<int> new_seam)
{
	std::vector<int> new_seam_sig(para_mesh.n_vertices(), false);
	for (int i = 0; i < new_seam.size(); i++)
	{
		if (!new_seam_sig[new_seam[i]])
		{
			new_seam_sig[new_seam[i]] = true;
			Mesh::VertexHandle v_it = para_mesh.vertex_handle(new_seam[i]);
			std::vector<OpenMesh::Vec3d> np1, np2; np1.reserve(6); np2.reserve(6);
			std::vector<OpenMesh::Vec3d> sampled_p; sampled_p.reserve(12);
			OpenMesh::Vec3d p0 = para_mesh.point(v_it);
			for (auto voh_it = para_mesh.voh_begin(v_it); voh_it != para_mesh.voh_end(v_it); ++voh_it)
			{
				Mesh::FaceHandle f_it = para_mesh.face_handle(*voh_it);
				if (f_it != Mesh::InvalidFaceHandle)
				{
					OpenMesh::Vec3d & p1 = para_mesh.point(para_mesh.to_vertex_handle(*voh_it));
					np1.push_back(p1);
					OpenMesh::Vec3d & p2 = para_mesh.point(para_mesh.to_vertex_handle(para_mesh.next_halfedge_handle(*voh_it)));
					np2.push_back(p2);
					sampled_p.push_back(0.9*p0 + 0.05*p1 + 0.05*p2);
				}
				if (!para_mesh.is_boundary(para_mesh.edge_handle(*voh_it)))
				{
					OpenMesh::Vec3d & p1 = para_mesh.point(para_mesh.to_vertex_handle(*voh_it));
					sampled_p.push_back(0.9*p0 + 0.1*p1);
				}
			}
			double e = 1e10; int idx = -1;
			for (int j = 0; j < sampled_p.size(); j++)
			{
				if (local_check_negative_area(sampled_p[j], np1, np2))
				{
					double mid_e = local_isotropy_energy(sampled_p[j], np1, np2);
					if (mid_e < e)
					{
						e = mid_e;
						idx = j;
					}
				}
			}
			if (idx != -1)
			{
				para_mesh.set_point(v_it, sampled_p[idx]);
			}
		}
	}
}

double MeshCut::local_isotropy_energy(Mesh::Point &p, std::vector<Mesh::Point> &np1, std::vector<Mesh::Point> &np2)
{
	double dis_nenrgy = 0.0; double aspect_ratio;
	for (int i = 0; i < np1.size(); i++)
	{
		double a = (np1[i] - p).norm();
		double b = (np2[i] - p).norm();
		double c = (np1[i] - np2[i]).norm();
		aspect_ratio = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
		double v = p | (np1[i] % np2[i]);
		dis_nenrgy += aspect_ratio;
	}
	return dis_nenrgy;
}

bool MeshCut::local_check_negative_area(Mesh::Point &p, std::vector<Mesh::Point> &n_p1, std::vector<Mesh::Point> &n_p2)
{
	for (int i = 0; i < n_p1.size(); i++)
	{
		OpenMesh::Vec3d n = (n_p1[i] - p) % (n_p2[i] - p);
		if (n[2] < 1e-12)
		{
			return false;
		}
	}
	return true;
}

void MeshCut::Mark_Vertex_Edge()
{
	candidate_seam_vertex.clear();
	candidate_seam_vertex.resize(mesh.n_vertices(), false);
	candidate_seam_edge.clear();
	candidate_seam_edge.resize(mesh.n_edges(), false);

	candidate_seam_vertex[boundary_points[0]] = true;
	for (size_t i = 0; i + 1 < boundary_points.size(); i++)
	{
		candidate_seam_vertex[boundary_points[i + 1]] = true;
		for (const auto& heh : mesh.voh_range(mesh.vertex_handle(boundary_points[i])))
		{
			if (mesh.to_vertex_handle(heh) == mesh.vertex_handle(boundary_points[i + 1]))
			{
				candidate_seam_edge[heh.idx() >> 1] = true;
			}
		}
	}
}

void MeshCut::Get_Valence()
{
	candidate_cut_valence.clear();
	candidate_cut_valence.resize(mesh.n_vertices(), 0);
	for (auto v : mesh.vertices())
	{
		int idx = v.idx();
		if (!candidate_seam_vertex[idx])
		{
			continue;
		}
		for (auto v_e : mesh.ve_range(v))
		{
			if (candidate_seam_edge[v_e.idx()])
			{
				candidate_cut_valence[idx]++;
			}
		}
	}
	big_valance_point_number = 0;
	for (int i = 0; i < mesh.n_vertices(); ++i)
	{
		if (candidate_cut_valence[i] > 2)
		{
			big_valance_point_number++;
		}
	}
	std::cout << "the number of the points which valance is bigger than 2:" << big_valance_point_number << std::endl;
}

int MeshCut::find_largest_distortion_v(double thresh_hold)
{
	int max_v = -1; double max_d = -1;
	for (auto v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it)
	{
		if (candidate_seam_vertex[v_it->idx()])
		{
			continue;
		}
		double d = 0;
		for (auto vf_it = mesh.vf_begin(*v_it); vf_it != mesh.vf_end(*v_it); ++vf_it)
		{
			int vf_idx = vf_it->idx();
			d += f_dis[vf_idx];
		}
		if (d > max_d)
		{
			max_d = d;
			max_v = v_it->idx();
		}
	}
	if (candidate_seam_vertex[max_v] || max_d < thresh_hold)
	{
		return -1;
	}
	else
	{
		return max_v;
	}
}

int MeshCut::find_largest_curvature_v(std::vector<int> & sig)
{
	int max_v = -1; double max_c = -1;
	for (int i = 0; i < sig.size(); i++)
	{
		if (sig[i])
		{
			continue;
		}
		if (v_gausscurvature[i] > max_c)
		{
			max_c = v_gausscurvature[i];
			max_v = i;
		}
	}
	return max_v;
}

void MeshCut::compute_all_triangle_dis(const Mesh & para_mesh, double angle_area_ratio)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	f_dis.resize(mesh.n_faces());
	unsigned counter = 0;
	for (auto f_it = para_mesh.faces_begin(); f_it != para_mesh.faces_end(); ++f_it)
	{
		Mesh::FaceVertexIter fv_it = para_mesh.cfv_iter(*f_it); Mesh::Point p0 = para_mesh.point(*fv_it);
		++fv_it; Mesh::Point p1 = para_mesh.point(*fv_it);
		++fv_it; Mesh::Point p2 = para_mesh.point(*fv_it);
		double l0 = (p1 - p0).norm();
		double l1 = (p2 - p1).norm();
		double l2 = (p0 - p2).norm();
		OpenMesh::Vec3d s = (p1 - p0) % (p2 - p1);
		double area_para = s.norm();
		double e = (alpha*((omega0[counter] * l0*l0 + omega1[counter] * l1*l1 + omega2[counter] * l2*l2) / area_para) + beta*(area_para / face_area[counter] + face_area[counter] / area_para))*0.5;
		e = face_area[counter] / area_para;
		f_dis[counter] = e;
		//f_dis[counter] = std::pow(e,5);
		counter++;
	}
}

std::vector<std::vector<double>> MeshCut::get_weight_of_matrix(Mesh & para_mesh, std::vector<double>& metric_, std::vector<int> boundary_p)
{
	is_boundary.clear();
	is_boundary.resize(mesh.n_vertices(), false);
	for (int i = 0; i < boundary_p.size(); i++)
	{
		//is_boundary[idx_to_mesh_idx[boundary_p[i]]] = true;
		is_boundary[boundary_p[i]] = true;
	}
	unsigned counter = 0;
	edge_weight.resize(mesh.n_edges());
	for (auto e_it = mesh.edges_begin(); e_it != mesh.edges_end(); ++e_it)
	{
		Mesh::HalfedgeHandle h_e_it = mesh.halfedge_handle(*e_it, 0);
		int v_idx1 = mesh.to_vertex_handle(h_e_it).idx();
		int v_idx2 = mesh.to_vertex_handle(mesh.opposite_halfedge_handle(h_e_it)).idx();
		if (is_boundary[v_idx1] || is_boundary[v_idx2])
		{
			edge_weight[counter] = max;
		}
		else
		{
			int f_idx1 = mesh.face_handle(h_e_it).idx();
			int f_idx2 = mesh.face_handle(mesh.opposite_halfedge_handle(h_e_it)).idx();
			//edge_weight[counter] = 1.0/(f_dis[f_idx1] + f_dis[f_idx2]);  // use triangle distortion
			//edge_weight[counter] = 1.0 / (f_gauss_curvature[f_idx1] + f_gauss_curvature[f_idx2]);
			edge_weight[counter] = 1.0 / (metric_[f_idx1] + metric_[f_idx2]);
		}
		counter++;
	}
	one_ring_weight.clear();
	one_ring_weight.resize(mesh.n_vertices());
	for (auto v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it)
	{
		int v_idx = v_it->idx();
		one_ring_weight[v_idx].reserve(16);
		for (auto ve_it = mesh.ve_begin(*v_it); ve_it != mesh.ve_end(*v_it); ++ve_it)
		{
			int e_idx = ve_it->idx();
			one_ring_weight[v_idx].push_back(edge_weight[e_idx]);
		}
	}
	return one_ring_weight;
}

void MeshCut::prepare_compute_distortion()
{
	if (face_area.size() == mesh.n_faces())
	{
		return;
	}
	size_t nf = mesh.n_faces();
	omega0.resize(nf);
	omega1.resize(nf);
	omega2.resize(nf);
	face_area.resize(nf);
	unsigned counter = 0;
	for (auto f_it = mesh.faces_begin(); f_it != mesh.faces_end(); ++f_it)
	{
		Mesh::FaceVertexIter fv_it = mesh.fv_iter(*f_it); Mesh::Point o0 = mesh.point(*fv_it);
		++fv_it; Mesh::Point o1 = mesh.point(*fv_it);
		++fv_it; Mesh::Point o2 = mesh.point(*fv_it);
		OpenMesh::Vec3d o_0 = o1 - o0;
		OpenMesh::Vec3d o_1 = o2 - o1;
		OpenMesh::Vec3d o_2 = o0 - o2;
		double area_ori = (o_0%o_1).norm();
		double a0 = acos((o2 - o0) | (o_1) / (o_2.norm()) / (o_1.norm()));
		double a1 = acos((o0 - o1) | (o_2) / (o_0.norm()) / (o_2.norm()));
		double a2 = acos((o0 - o1) | (o_1) / (o_0.norm()) / (o_1.norm()));
		double  omega0_ = cos(a0) / sin(a0);
		double  omega1_ = cos(a1) / sin(a1);
		double  omega2_ = cos(a2) / sin(a2);
		omega0[counter] = omega0_;
		omega1[counter] = omega1_;
		omega2[counter] = omega2_;
		face_area[counter] = area_ori;
		counter++;
	}
}

std::vector<int> MeshCut::find_new_boundary(int update_l, std::vector<double>& metric_)
{
	std::vector<double> e_w(boundary_number);
	for (int i = 0; i < boundary_number - 1; i++)
	{
		Mesh::VertexHandle v_it1 = mesh.vertex_handle(idx_to_mesh_idx[i]);
		Mesh::VertexHandle v_it2 = mesh.vertex_handle(idx_to_mesh_idx[i + 1]);
		Mesh::HalfedgeHandle he_it = mesh.find_halfedge(v_it1, v_it2);
		int f_idx1 = mesh.face_handle(he_it).idx();
		int f_idx2 = mesh.face_handle(mesh.opposite_halfedge_handle(he_it)).idx();
		//e_w[i] = f_dis[f_idx1] + f_dis[f_idx2];  // use triangle distortion
		//e_w[i] = f_gauss_curvature[f_idx1] + f_gauss_curvature[f_idx2];
		e_w[i] = metric_[f_idx1] + metric_[f_idx2];
	}
	Mesh::VertexHandle v_it1 = mesh.vertex_handle(idx_to_mesh_idx[boundary_number - 1]);
	Mesh::VertexHandle v_it2 = mesh.vertex_handle(idx_to_mesh_idx[0]);
	Mesh::HalfedgeHandle he_it = mesh.find_halfedge(v_it1, v_it2);
	int f_idx1 = mesh.face_handle(he_it).idx();
	int f_idx2 = mesh.face_handle(mesh.opposite_halfedge_handle(he_it)).idx();
	//e_w[boundary_number -1] = f_dis[f_idx1] + f_dis[f_idx2];   // use triangle distortion
	//e_w[boundary_number - 1] = f_gauss_curvature[f_idx1] + f_gauss_curvature[f_idx2];
	e_w[boundary_number - 1] = metric_[f_idx1] + metric_[f_idx2];

	double max_edges_weight = -1;
	big_v.clear();
	int max_e_w_idx = -1;
	for (int i = 0; i <= boundary_number - update_l; i++)
	{
		double edge_wei = 0;
		bool no_v_1_sig = true;
		std::vector<int> mid_big_v; mid_big_v.reserve(10);
		for (int j = 0; j < update_l; j++)
		{
			if (candidate_cut_valence[idx_to_mesh_idx[i + j]] == 1 && j != 0 && j != (update_l - 1))
			{
				no_v_1_sig = false;
				break;
			}
			edge_wei += e_w[i + j];
			if (candidate_cut_valence[idx_to_mesh_idx[i + j]] >2 && j != 0 && j != (update_l - 1))
			{
				mid_big_v.push_back(idx_to_mesh_idx[i + j]);
			}
		}
		if (edge_wei > max_edges_weight && no_v_1_sig)
		{
			max_edges_weight = edge_wei;
			big_v = mid_big_v;
			max_e_w_idx = i;
		}
	}
	std::cout << "number of big valence: " << big_v.size() << std::endl;
	std::vector<int> selected_boundary(update_l);
	if (max_e_w_idx == -1)
	{
		std::cout << "can not select boundary points !" << "  " << std::endl;
		double max_edges_weight = -1;
		big_v.clear();
		int max_e_w_idx = -1;
		for (int i = 0; i <= boundary_number - update_l; i++)
		{
			double edge_wei = 0;
			bool no_v_1_sig = true;
			std::vector<int> mid_big_v; mid_big_v.reserve(10);
			for (int j = 0; j < update_l; j++)
			{
				if (candidate_cut_valence[idx_to_mesh_idx[i + j]] == 1 && j != 0 && j != (update_l - 1))
				{
					no_v_1_sig = false;
					std::cout << i << "  " << j << "  " << idx_to_mesh_idx[i + j] << "  " << no_v_1_sig << std::endl;
					break;
				}
			}
		}
		selected_boundary.clear();
		return selected_boundary;
	}
	for (int i = 0; i < update_l; i++)
	{
		selected_boundary[i] = idx_to_mesh_idx[max_e_w_idx + i];
		//selected_boundary[i] = max_edges_weight + i;
	}
	return selected_boundary;

}

void MeshCut::add_new_boundary_points(std::vector<int>& a)
{
	if (a.size() == 0)
	{
		std::cout << "the size of a is 0" << std::endl;
		return;
	}
	candidate_seam_vertex[a[0]] = true;
	for (int i = 0; i < a.size() - 1; ++i)
	{
		candidate_seam_vertex[a[i + 1]] = true;
		Mesh::VHandle vh = mesh.vertex_handle(a[i]);
		Mesh::VHandle vh1 = mesh.vertex_handle(a[i + 1]);
		for (auto hh : mesh.voh_range(vh))
		{
			if (mesh.to_vertex_handle(hh) == vh1)
			{
				Mesh::EHandle eh = mesh.edge_handle(hh);
				candidate_seam_edge[eh.idx()] = true;
			}
		}
	}
}

Mesh MeshCut::mesh_ref()
{
	return mesh;
}

std::vector<int> MeshCut::remove_selected_boundary(std::vector<int> & selected_b)
{
	for (int i = 0; i < selected_b.size(); i++)
	{
		//std::cout << candidate_seam_vertex[selected_b[i]] << std::endl;
		candidate_seam_vertex[selected_b[i]] = false;
	}
	std::vector<int> boundary_p;
	for (int i = 0; i < candidate_seam_vertex.size(); i++)
	{
		if (candidate_seam_vertex[i])
		{
			boundary_p.push_back(i);
		}
	}
	for (int i = 0; i < candidate_seam_edge.size(); i++)
	{
		if (candidate_seam_edge[i])
		{
			int idx1 = mesh.to_vertex_handle(mesh.halfedge_handle(mesh.edge_handle(i), 0)).idx();
			int idx2 = mesh.to_vertex_handle(mesh.halfedge_handle(mesh.edge_handle(i), 1)).idx();
			if (!candidate_seam_vertex[idx1] && !candidate_seam_vertex[idx2])
			{
				candidate_seam_edge[i] = false;
			}
		}
	}
	std::cout << "remove ok !" << std::endl;
	return boundary_p;
}

void MeshCut::set_edge_signal(std::vector<int> & e)
{
	candidate_seam_vertex.clear();
	candidate_seam_vertex.resize(mesh.n_vertices(), false);
	candidate_seam_edge.clear();
	candidate_seam_edge.resize(mesh.n_edges(), false);

	for (int i = 0; i < e.size(); ++i)
	{
		candidate_seam_vertex[e[i]] = true;
	}

	for (int i = 0; i < e.size(); i++)
	{
		for (auto v_e_it = mesh.voh_begin(mesh.vertex_handle(e[i])); v_e_it != mesh.voh_end(mesh.vertex_handle(e[i])); ++v_e_it)
		{
			if (candidate_seam_vertex[mesh.to_vertex_handle(*v_e_it).idx()])
			{
				Mesh::EHandle eh = mesh.edge_handle(*v_e_it);
				candidate_seam_edge[eh.idx()] = true;
				//std::cout << "*** " << eh.idx() << std::endl;
			}
		}
	}
}

void MeshCut::calc_gauss_curvature(Mesh &mesh_)
{
	Mesh::VertexIter        v_it, v_end(mesh_.vertices_end());
	Mesh::VertexVertexIter  vv_it, vv_it2;
	Mesh::Point             d0, d1;
	Mesh::Scalar            angles;
	Mesh::Scalar            lb(-1.0), ub(1.0);
	Mesh::VertexOHalfedgeIter h_o;
	double PI = 3.1415926;
	// ------------- IMPLEMENT HERE ---------
	// TASK 3.4 Approximate Gaussian curvature.
	// Hint: When calculating angles out of cross products make sure the value 
	// you pass to the acos function is between -1.0 and 1.0.
	// Use the vweight_ property for the area weight.
	// ------------- IMPLEMENT HERE ---------
	v_gausscurvature.clear(); v_gausscurvature.resize(mesh_.n_vertices());
	int counter = 0;
	for (v_it = mesh_.vertices_begin(); v_it != v_end; ++v_it)
	{
		angles = 0.0;
		double area_ = 0.0;
		for (h_o = mesh_.voh_iter(*v_it); h_o.is_valid(); ++h_o)
		{
			Mesh::HalfedgeHandle h_n = mesh_.next_halfedge_handle(*h_o);
			Mesh::VertexHandle vv1 = mesh_.to_vertex_handle(*h_o);
			Mesh::VertexHandle vv2 = mesh_.to_vertex_handle(h_n);
			OpenMesh::Vec3d p0 = mesh_.point(*v_it);
			OpenMesh::Vec3d p1 = mesh_.point(vv1);
			OpenMesh::Vec3d p2 = mesh_.point(vv2);
			area_ += ((p1 - p0) % (p2 - p0)).norm()*0.5;
			p1 = (p1 - p0).normalize();
			p2 = (p2 - p0).normalize();
			angles += acos(std::min(0.999999, std::max(-0.999999, (p1 | p2))));
		}
		v_gausscurvature[counter] = (2.0*PI - angles) / (area_ / 3.0);
		counter++;
	}
	f_gauss_curvature.clear(); f_gauss_curvature.resize(mesh_.n_faces());
	counter = 0;
	for (auto f_it = mesh_.faces_begin(); f_it != mesh_.faces_end(); ++f_it)
	{
		f_gauss_curvature[counter] = 0.0;
		for (auto fv_it = mesh_.fv_begin(*f_it); fv_it != mesh_.fv_end(*f_it); ++fv_it)
		{
			int fv_idx = fv_it->idx();
			f_gauss_curvature[counter] += v_gausscurvature[fv_idx];
		}
		f_gauss_curvature[counter] /= 3.0;
		counter++;
	}
	for (int i = 0; i < f_gauss_curvature.size(); i++)
	{
		f_gauss_curvature[i] = std::pow(std::fabs(f_gauss_curvature[i]) + 1.0, 5);
		//std::cout << f_gauss_curvature[i] << std::endl;
	}
	/*auto min_ = std::min_element(std::begin(f_gauss_curvature), std::end(f_gauss_curvature));
	double m = *min_; m -= 0.01;
	for (int i = 0; i < f_gauss_curvature.size(); i++)
	{
	f_gauss_curvature[i] -= m;
	}*/
	//e_gauss_curvature.clear(); e_gauss_curvature.resize(mesh_.n_edges());
	//counter = 0;
}

std::vector<double> MeshCut::get_triangle_distortion()
{
	return f_dis;
}

std::vector<int> MeshCut::find_selected_idx_of_v(Mesh& para_mesh, std::vector<int> & find_p)
{
	std::vector<std::vector<int>> idx_f_v;
	for (int i = 0; i < find_p.size(); i++)
	{
		Mesh::VertexHandle v_it = mesh.vertex_handle(find_p[i]);
		for (auto vh_it = mesh.voh_begin(v_it); vh_it != mesh.voh_end(v_it); ++vh_it)
		{
			Mesh::FaceHandle f_it = mesh.face_handle(*vh_it);
			if (f_it != Mesh::InvalidFaceHandle)
			{
				std::vector<int> mid_idx_f_v;
				mid_idx_f_v.push_back(f_it.idx());
				//std::cout << "face id: " << f_it.idx() << std::endl;
				unsigned counter = 0;
				for (auto fv_it = mesh.fv_begin(f_it); fv_it != mesh.fv_end(f_it); ++fv_it)
				{
					if (fv_it->idx() == find_p[i])
					{
						mid_idx_f_v.push_back(counter);
						break;
					}
					counter++;
				}
				idx_f_v.push_back(mid_idx_f_v);
			}
		}
	}

	std::vector<int> idx_v;
	for (int i = 0; i < idx_f_v.size(); i++)
	{
		Mesh::FaceHandle f_it = para_mesh.face_handle(idx_f_v[i][0]);
		unsigned counter = 0;
		for (auto fv_it = para_mesh.fv_begin(f_it); fv_it != para_mesh.fv_end(f_it); ++fv_it)
		{
			if (idx_f_v[i][1] == counter)
			{
				idx_v.push_back(fv_it->idx());
				break;
			}
			counter++;
		}
	}
	return idx_v;
}

std::vector<int> MeshCut::find_high_curvature_point(Mesh & m, double threshhold)
{
	std::vector<int> h_c_p;
	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		if (!m.is_boundary(*v_it))
		{
			OpenMesh::Vec3d p0 = m.point(*v_it);
			double angle_ = 0.0;
			for (auto voh_it = m.voh_begin(*v_it); voh_it != m.voh_end(*v_it); ++voh_it)
			{
				Mesh::FaceHandle f_it = m.face_handle(*voh_it);
				if (f_it != Mesh::InvalidFaceHandle)
				{
					Mesh::HalfedgeHandle h_it = m.next_halfedge_handle(*voh_it);
					OpenMesh::Vec3d p1 = m.point(m.to_vertex_handle(*voh_it));
					OpenMesh::Vec3d p2 = m.point(m.to_vertex_handle(h_it));
					angle_ += std::acos(((p1 - p0) | (p2 - p0)) / (p1 - p0).norm() / (p2 - p0).norm());
				}
			}
			angle_ /= (2.0*M_PI);
			if (angle_ < threshhold)
			{
				h_c_p.push_back(v_it->idx());
			}
		}
	}
	return h_c_p;
}

void MeshCut::triangle_distortion(Mesh * mesh_, Mesh * m1)
{
	double max_iso_dis = -1.0;;
	std::vector<double>isometric_distortion;
	std::vector<int> flipped_tri, cd_above_1000_tri;
	OpenMesh::Vec3d face_nor; double face_area;
	Mesh::FaceHalfedgeIter fhe_it;
	Mesh::HalfedgeHandle heh; Mesh::VertexHandle vh;
	OpenMesh::Vec3d e_v; OpenMesh::Vec3d p_v;
	std::vector<OpenMesh::Vec3d> v_p_on_plane(3); v_p_on_plane[0] = OpenMesh::Vec3d(0, 0, 0);
	std::vector<OpenMesh::Vec3d> v_q_on_plane(3); v_q_on_plane[0] = OpenMesh::Vec3d(0, 0, 0);
	double len; int face_count = 0; int face_id;
	int max_iso_face = 0; double ave_iso_dis = 0;
	double min_iso_error = 1e30;
	isometric_distortion.clear(); isometric_distortion.resize(mesh_->n_faces());
	int flip_tri_count = 0; flipped_tri.clear();
	stretch_dis.clear(); stretch_dis.resize(mesh_->n_faces());
	max_stretch_d = -1; max_stretch_idx = -1;

	for (Mesh::FaceIter f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		face_id = f_it->idx();
		auto fhe1 = m1->fh_iter(m1->face_handle(face_id));
		OpenMesh::Vec3d p0 = m1->point(m1->vertex_handle(m1->from_vertex_handle(*fhe1).idx()));
		OpenMesh::Vec3d p1 = m1->point(m1->vertex_handle(m1->to_vertex_handle(*fhe1).idx()));
		OpenMesh::Vec3d p2 = m1->point(m1->vertex_handle(m1->to_vertex_handle(m1->next_halfedge_handle(*fhe1)).idx()));
		face_nor = OpenMesh::cross(p1 - p0, p2 - p0); face_area = face_nor.norm()*0.5; face_nor.normalize();
		len = (p1 - p0).norm();
		v_p_on_plane[1] = OpenMesh::Vec3d(len, 0.0, 0.0);

		OpenMesh::Vec3d e1 = p1 - p0;
		e1 /= e1.norm();
		OpenMesh::Vec3d e2 = OpenMesh::cross(face_nor, e1);
		e2 /= e2.norm();
		heh = m1->prev_halfedge_handle(*fhe1);
		OpenMesh::Vec3d temp_v2 = p2 - p0;
		v_p_on_plane[2][0] = OpenMesh::dot(temp_v2, e1);
		v_p_on_plane[2][1] = OpenMesh::dot(temp_v2, e2);
		v_p_on_plane[2][2] = 0.0;

		fhe_it = mesh_->fh_iter(*f_it);
		p0 = mesh_->point(mesh_->from_vertex_handle(*fhe_it));
		p1 = mesh_->point(mesh_->to_vertex_handle(*fhe_it));
		p2 = mesh_->point(mesh_->to_vertex_handle(mesh_->next_halfedge_handle(*fhe_it)));
		face_nor = OpenMesh::cross(p1 - p0, p2 - p0); face_nor.normalize();
		//face_nor = OpenMesh::Vec3d(0, 0, 1);
		//face_nor = (p0+p1+p2).normalize();
		len = (p1 - p0).norm();
		v_q_on_plane[1] = OpenMesh::Vec3d(len, 0.0, 0.0);

		e1 = p1 - p0; e1 /= e1.norm();
		e2 = OpenMesh::cross(face_nor, e1); e2 /= e2.norm();
		heh = mesh_->prev_halfedge_handle(*fhe_it);
		temp_v2 = p2 - p0;
		v_q_on_plane[2][0] = OpenMesh::dot(temp_v2, e1);
		v_q_on_plane[2][1] = OpenMesh::dot(temp_v2, e2);
		v_q_on_plane[2][2] = 0.0;

		OpenMesh::Vec3d d_U(0, 0, 0); OpenMesh::Vec3d d_V(0, 0, 0);
		for (int i = 0; i < 3; ++i)
		{
			p_v = v_q_on_plane[(i + 2) % 3];
			e_v = v_p_on_plane[(i + 1) % 3] - v_p_on_plane[i];

			d_U += p_v[0] * e_v;
			d_V += p_v[1] * e_v;
		}
		d_U /= (2.0 * face_area);
		d_V /= (2.0 * face_area);

		Eigen::Matrix2d J;
		J(0, 0) = d_U[0]; J(1, 0) = d_U[1]; J(0, 1) = d_V[0]; J(1, 1) = d_V[1];
		double det_J = J.determinant();
		if (det_J > 0)
		{
			Eigen::JacobiSVD<Eigen::Matrix2d> svd(J, Eigen::ComputeFullU | Eigen::ComputeFullV);
			Eigen::Vector2d s_v = svd.singularValues();
			double temp_error = s_v(0) > 1.0 / s_v(1) ? s_v(0) : 1.0 / s_v(1);
			isometric_distortion[face_id] = temp_error;
			if (temp_error > max_iso_dis)
			{
				max_iso_dis = temp_error; max_iso_face = face_id;
			}
			if (temp_error < min_iso_error)
			{
				min_iso_error = temp_error;
			}
			ave_iso_dis += temp_error;
			stretch_dis[face_id] = std::sqrt(0.5*(s_v(0)*s_v(0) + s_v(1)*s_v(1)));
			//std::cout << stretch_dis[face_id] << std::endl;
			if (max_stretch_d < stretch_dis[face_id])
			{
				max_stretch_d = stretch_dis[face_id];
				max_stretch_idx = face_id;
			}
		}
		else
		{
			isometric_distortion[face_id] = -1;
			stretch_dis[face_id] = -1;
			++flip_tri_count;
			flipped_tri.push_back(face_id);
		}
	}
	f_dis = isometric_distortion;
	/*f_dis.resize(mesh_->n_faces());
	for (int i = 0; i < mesh_->n_faces(); i++)
	{
	f_dis[i] = std::pow(isometric_distortion[i],2);
	}*/
	std::cout << "max iso dis: " << max_iso_dis << "   min_iso_dis: " << min_iso_error << "  ave iso dis: " << ave_iso_dis / (f_dis.size() - flip_tri_count) << std::endl;
}
#if 0
std::vector<OpenMesh::Vec3d> MeshCut::clustered_points(std::vector<OpenMesh::Vec3d>& date_set)
{
	std::vector<OpenMesh::Vec3d> c_p;
	real_2d_array xy;
	double* data;
	/*data = new double[2*date_set.size()];
	for (int i = 0; i < date_set.size(); i++)
	{
	data[2 * i] = date_set[i][0];
	data[2 * i + 1] = date_set[i][1];
	}
	xy.setcontent(date_set.size(), 2, data);

	clusterizerstate s;
	kmeansreport rep;
	clusterizercreate(s);
	clusterizersetpoints(s, xy, 2);
	clusterizersetkmeanslimits(s, 5, 0);*/

	data = new double[3 * date_set.size()];
	for (int i = 0; i < date_set.size(); i++)
	{
		data[3 * i] = date_set[i][0];
		data[3 * i + 1] = date_set[i][1];
		data[3 * i + 2] = date_set[i][2];
	}
	xy.setcontent(date_set.size(), 3, data);

	clusterizerstate s;
	kmeansreport rep;
	clusterizercreate(s);
	clusterizersetpoints(s, xy, 2);
	clusterizersetkmeanslimits(s, 5, 0);

	std::vector<kmeansreport> s_c_p;
	for (int k = 1; k < 25; k++)
	{
		clusterizerrunkmeans(s, k, rep);
		std::cout << "energy:  " << rep.energy << std::endl;
		s_c_p.push_back(rep);
	}

	unsigned max_idx = -1; double max_ = -1;
	for (int i = 2; i < s_c_p.size() - 1; i++)
	{
		//double g = (s_c_p[i - 1].energy - s_c_p[i].energy) - (s_c_p[i].energy - s_c_p[i + 1].energy);
		double g = (s_c_p[i - 1].energy - s_c_p[i].energy) - (s_c_p[i].energy - s_c_p[i + 1].energy);
		std::cout << g << std::endl;
		if (g > max_)
		{
			max_idx = i;
			max_ = g;
		}
	}
	rep = s_c_p[max_idx];
	std::cout << "max_idx: " << max_idx << "    energy: " << rep.energy << std::endl;
	for (int i = 0; i < rep.c.rows(); i++)
	{
		std::cout << rep.c[i][0] << "  " << rep.c[i][1] << "  " << rep.c[i][2] << std::endl;
		//c_p.push_back(OpenMesh::Vec3d(rep.c[i][0], rep.c[i][1], 0.0));
		c_p.push_back(OpenMesh::Vec3d(rep.c[i][0], rep.c[i][1], rep.c[i][2]));
	}
	std::cout << "s_c_p[idx].cidx size: " << rep.cidx.length() << "   rep.c size: " << rep.c.rows() << "  " << rep.c.cols() << std::endl;

	//
	// We've performed clusterization, and it succeeded (completion code is +1).
	//
	// Now first center is stored in the first row of rep.c, second one is stored
	// in the second row. rep.cidx can be used to determine which center is
	// closest to some specific point of the dataset.
	//

	printf("%d\n", int(rep.terminationtype)); // EXPECTED: 1
	std::cout << "the cluster is over !" << std::endl;
	return c_p;
}
#endif
void MeshCut::PersistenceClustering(const Mesh & mesh, const double & tau)
{
	// Step 1: compute a point wise function
	std::vector<double> vertdis(mesh.n_vertices());
	std::vector<int> v2v(mesh.n_vertices());
	std::vector<int> v2vi(mesh.n_vertices());
	for (const auto & vh : mesh.vertices())
	{
		double vdis = 0.0;
		double varea = 0.0;
		for (const auto & vfh : mesh.vf_range(vh))
		{
			vdis += face_area[vfh.idx()] * f_dis[vfh.idx()];
			varea += face_area[vfh.idx()];
		}
		vdis /= varea;
		vertdis[vh.idx()] = vdis;
		v2v[vh.idx()] = vh.idx();
	}

	// Step 2: sort the vertices
	std::sort(v2v.begin(), v2v.end(), [&vertdis](const auto &vv1, const auto &vv2) {
		return vertdis[vv1] > vertdis[vv2];
	});
	for (size_t i = 0; i < v2v.size(); i++)
	{
		v2vi[v2v[i]] = i;
	}
	
	// Step 3: initialize data structure
	std::list<std::pair<size_t, std::set<size_t>>> U;
	std::vector<int> g(mesh.n_vertices(), -1);
	for (size_t i = 0; i < v2v.size(); i++)
	{
		// Step 3.1: compute higher neighbor vertices
		std::vector<int> nei;
		for (const auto & vvh : mesh.vv_range(mesh.vertex_handle(v2v[i])))
		{
			if (v2vi[vvh.idx()] < i)
			{
				nei.push_back(v2vi[vvh.idx()]);
			}
		}
		if (nei.empty())
		{
			// vertex i is a peak of f within mesh
			// create a new entry e in U and attach vertex i to it
			U.push_back(std::make_pair(i, std::set<size_t>({ i })));

		}
		else
		{
			// vertex i is not a peak of f within mesh
			g[i] = nei[0];
			double maxf = vertdis[v2v[g[i]]];
			for (const auto & n : nei)
			{
				if (vertdis[v2v[n]] > maxf)
				{
					maxf = vertdis[v2v[n]];
					g[i] = n;
				}
			}
			auto ei = U.end();
			for (auto eit = U.begin(); eit != U.end(); ++eit)
			{
				if (eit->second.find(g[i]) != eit->second.end())
				{
					ei = eit;
					break;
				}
			}
			ei->second.insert(i);
			for (const auto & j : nei)
			{
				auto e = U.end();
				for (auto eit = U.begin(); eit != U.end(); ++eit)
				{
					if (eit->second.find(j) != eit->second.end())
					{
						e = eit;
						break;
					}
				}
				auto mine = vertdis[v2v[e->first]] < vertdis[v2v[ei->first]] ? e : ei;
				auto maxe = vertdis[v2v[e->first]] < vertdis[v2v[ei->first]] ? ei : e;
				if (e->first != ei->first && vertdis[v2v[mine->first]] < vertdis[v2v[i]] + tau)
				{
					maxe->second.insert(mine->second.begin(), mine->second.end());
					ei = maxe;
					U.erase(mine);
				}
			}
		}
	}
	c_p_idx.clear();
	for (const auto & e : U)
	{
		c_p_idx.push_back(v2v[e.first]);
	}
}

void MeshCut::clustered_points_separate(const Mesh & para_mesh, std::vector<int>& date_set, double threshhold)
{
	if (date_set.size() <= threshhold)
	{
		std::cout << "class size: " << date_set.size() << std::endl;
		tri_idx.insert(tri_idx.end(), date_set.begin(), date_set.end());
		return;
	}
	std::vector<OpenMesh::Vec3d> c_p;
	std::vector<int> class_idx(date_set.size(), -1);
	std::vector<std::vector<int>> cidx;
	int separated_n = 0;
	std::vector<int> tri_sig(mesh.n_faces(), false);
	std::vector<int> tri_class_sig(mesh.n_faces(), true);
	for (int i = 0; i < date_set.size(); i++)
	{
		tri_sig[date_set[i]] = true;
	}

	while (separated_n < date_set.size())
	{
		std::vector<int> c;
		for (int i = 0; i < date_set.size(); i++)
		{
			if (tri_class_sig[date_set[i]])
			{
				c.push_back(date_set[i]);
				tri_class_sig[date_set[i]] = false;
				separated_n++;
				for (int j = 0; j < c.size(); j++)
				{
					/*for (auto f_it = mesh.ff_begin(mesh.face_handle(c[j])); f_it != mesh.ff_end(mesh.face_handle(c[j])); ++f_it)
					{
					int f_idx = f_it.handle().idx();
					if (tri_sig[f_idx] && tri_class_sig[f_idx])
					{
					c.push_back(f_idx);
					tri_class_sig[f_idx] = false;
					separated_n++;
					}
					}*/
					Mesh::FaceVertexIter fv_it = para_mesh.cfv_iter(para_mesh.face_handle(c[j]));
					for (auto f_it = mesh.vf_begin(*fv_it); f_it != mesh.vf_end(*fv_it); ++f_it)
					{
						int f_idx = f_it->idx();
						if (tri_sig[f_idx] && tri_class_sig[f_idx])
						{
							c.push_back(f_idx);
							tri_class_sig[f_idx] = false;
							separated_n++;
						}
					}
					++fv_it;
					for (auto f_it = mesh.vf_begin(*fv_it); f_it != mesh.vf_end(*fv_it); ++f_it)
					{
						int f_idx = f_it->idx();
						if (tri_sig[f_idx] && tri_class_sig[f_idx])
						{
							c.push_back(f_idx);
							tri_class_sig[f_idx] = false;
							separated_n++;
						}
					}
					++fv_it;
					for (auto f_it = mesh.vf_begin(*fv_it); f_it != mesh.vf_end(*fv_it); ++f_it)
					{
						int f_idx = f_it->idx();
						if (tri_sig[f_idx] && tri_class_sig[f_idx])
						{
							c.push_back(f_idx);
							tri_class_sig[f_idx] = false;
							separated_n++;
						}
					}
				}
				break;
			}
		}
		if (c.size() > threshhold)
		{
			cidx.push_back(c);
		}
	}

	for (int i = 0; i < cidx.size(); i++)
	{
		/*OpenMesh::Vec3d all_p(0.0, 0.0, 0.0);
		for (int j = 0; j < cidx[i].size(); j++)
		{
		Mesh::FaceVertexIter fv_it = para_mesh.fv_iter(para_mesh.face_handle(cidx[i][j]));
		OpenMesh::Vec3d p = para_mesh.point(fv_it); ++fv_it;
		p += para_mesh.point(fv_it); ++fv_it;
		p += para_mesh.point(fv_it);
		p /= 3.0;
		all_p += p;
		}
		all_p /= cidx[i].size();
		c_p.push_back(all_p.normalize());*/
		double d_max = -1; int max_idx = -1;
		for (int j = 0; j < cidx[i].size(); j++)
		{
			if (f_dis[cidx[i][j]] > d_max)
			{
				d_max = f_dis[cidx[i][j]];
				max_idx = j;
			}
		}
		selected_tri_num[cidx[i][max_idx]] += 1;
		//std::cout <<"**  " <<selected_tri[cidx[i][max_idx]] << std::endl;
		if (!selected_tri[cidx[i][max_idx]])
		{
			selected_tri[cidx[i][max_idx]] = true;
			auto fh = para_mesh.face_handle(cidx[i][max_idx]);
			int vid = 0;
			double vmaxdis = 0.0;
			for (const auto & fvh : para_mesh.fv_range(fh))
			{
				double vdis = 0.0;
				int vvalence = 0;
				for (const auto & vfh : para_mesh.vf_range(fvh))
				{
					vdis += f_dis[vfh.idx()];
					++vvalence;
				}
				vdis /= vvalence;
				if (vmaxdis < vdis)
				{
					vid = fvh.idx();
					vmaxdis = vdis;
				}
			}
			c_p_idx.push_back(vid);
			//Mesh::FaceVertexIter fv_it = para_mesh.cfv_iter(para_mesh.face_handle(cidx[i][max_idx]));
			//c_p_idx.push_back(fv_it->idx());
			tri_idx.insert(tri_idx.end(), cidx[i].begin(), cidx[i].end());
			//std::cout <<cidx[i].size() << std::endl;
		}
	}
	for (int i = 0; i < cidx.size(); i++)
	{
		std::vector<int> d_s = fliter_tri_by_middle_num(cidx[i]);
		if (d_s.size() > threshhold)
		{
			clustered_points_separate(para_mesh, d_s, threshhold);
		}
	}
	//std::cout <<"classic end !"<<"  class number: "<<cidx.size() << std::endl;
	//return c_p_idx;
}

std::vector<std::vector<int>> MeshCut::clustered_points_step(Mesh & para_mesh, const std::vector<int>& date_set, double threshhold)
{
	if (date_set.size() <= threshhold)
	{
		std::cout << "class size: " << date_set.size() << std::endl;
		tri_idx.insert(tri_idx.end(), date_set.begin(), date_set.end());
	}
	std::vector<OpenMesh::Vec3d> c_p;
	std::vector<int> class_idx(date_set.size(), -1);
	std::vector<std::vector<int>> cidx;
	int separated_n = 0;
	std::vector<int> tri_sig(mesh.n_faces(), false);
	std::vector<int> tri_class_sig(mesh.n_faces(), true);
	for (int i = 0; i < date_set.size(); i++)
	{
		tri_sig[date_set[i]] = true;
	}

	while (separated_n < date_set.size())
	{
		std::vector<int> c;
		for (int i = 0; i < date_set.size(); i++)
		{
			if (tri_class_sig[date_set[i]])
			{
				c.push_back(date_set[i]);
				tri_class_sig[date_set[i]] = false;
				separated_n++;
				for (int j = 0; j < c.size(); j++)
				{
					/*for (auto f_it = mesh.ff_begin(mesh.face_handle(c[j])); f_it != mesh.ff_end(mesh.face_handle(c[j])); ++f_it)
					{
					int f_idx = f_it.handle().idx();
					if (tri_sig[f_idx] && tri_class_sig[f_idx])
					{
					c.push_back(f_idx);
					tri_class_sig[f_idx] = false;
					separated_n++;
					}
					}*/
					Mesh::FaceVertexIter fv_it = para_mesh.fv_iter(para_mesh.face_handle(c[j]));
					for (auto f_it = mesh.vf_begin(*fv_it); f_it != mesh.vf_end(*fv_it); ++f_it)
					{
						int f_idx = f_it->idx();
						if (tri_sig[f_idx] && tri_class_sig[f_idx])
						{
							c.push_back(f_idx);
							tri_class_sig[f_idx] = false;
							separated_n++;
						}
					}
					++fv_it;
					for (auto f_it = mesh.vf_begin(*fv_it); f_it != mesh.vf_end(*fv_it); ++f_it)
					{
						int f_idx = f_it->idx();
						if (tri_sig[f_idx] && tri_class_sig[f_idx])
						{
							c.push_back(f_idx);
							tri_class_sig[f_idx] = false;
							separated_n++;
						}
					}
					++fv_it;
					for (auto f_it = mesh.vf_begin(*fv_it); f_it != mesh.vf_end(*fv_it); ++f_it)
					{
						int f_idx = f_it->idx();
						if (tri_sig[f_idx] && tri_class_sig[f_idx])
						{
							c.push_back(f_idx);
							tri_class_sig[f_idx] = false;
							separated_n++;
						}
					}
				}
				break;
			}
		}
		if (c.size() > threshhold)
		{
			cidx.push_back(c);
		}
	}

	for (int i = 0; i < cidx.size(); i++)
	{
		/*OpenMesh::Vec3d all_p(0.0, 0.0, 0.0);
		for (int j = 0; j < cidx[i].size(); j++)
		{
		Mesh::FaceVertexIter fv_it = para_mesh.fv_iter(para_mesh.face_handle(cidx[i][j]));
		OpenMesh::Vec3d p = para_mesh.point(fv_it); ++fv_it;
		p += para_mesh.point(fv_it); ++fv_it;
		p += para_mesh.point(fv_it);
		p /= 3.0;
		all_p += p;
		}
		all_p /= cidx[i].size();
		c_p.push_back(all_p.normalize());*/
		double d_max = -1; int max_idx = -1;
		for (int j = 0; j < cidx[i].size(); j++)
		{
			if (f_dis[cidx[i][j]] > d_max)
			{
				d_max = f_dis[cidx[i][j]];
				max_idx = j;
			}
		}
		selected_tri_num[cidx[i][max_idx]] += 1;
		//std::cout <<"**  " <<selected_tri[cidx[i][max_idx]] << std::endl;
		if (!selected_tri[cidx[i][max_idx]])
		{
			selected_tri[cidx[i][max_idx]] = true;
			Mesh::FaceVertexIter fv_it = para_mesh.fv_iter(para_mesh.face_handle(cidx[i][max_idx]));
			c_p_idx.push_back(fv_it->idx());
			tri_idx.insert(tri_idx.end(), cidx[i].begin(), cidx[i].end());
			//std::cout <<cidx[i].size() << std::endl;
		}
	}
	std::vector<std::vector<int>> dataset;
	for (int i = 0; i < cidx.size(); i++)
	{
		std::vector<int> d_s = fliter_tri_by_middle_num(cidx[i]);
		if (d_s.size() > threshhold)
		{
			dataset.push_back(d_s);
		}
	}
	return dataset;
	//std::cout <<"classic end !"<<"  class number: "<<cidx.size() << std::endl;
	//return c_p_idx;
}

std::vector<int> MeshCut::fliter_tri_by_middle_num(std::vector<int>& date_set)
{
	size_t size_ = date_set.size();
	std::vector<double> f_d(size_);
	for (size_t i = 0; i < size_; i++)
	{
		f_d[i] = f_dis[date_set[i]];
	}
	std::sort(f_d.begin(), f_d.end());
	double mid = f_d[size_ / 2];
	std::vector<int> d_s;
	for (size_t i = 0; i < size_; i++)
	{
		if (f_dis[date_set[i]] > mid)
		{
			d_s.push_back(date_set[i]);
		}
	}
	return d_s;
}

std::vector<int> MeshCut::fliter_tri_by_average(std::vector<int>& date_set)
{
	size_t size_ = date_set.size();
	double avg = 0.0;
	for (size_t i = 0; i < size_; i++)
	{
		avg += f_dis[date_set[i]];
	}
	double mid = avg / size_;
	std::vector<int> d_s;
	for (size_t i = 0; i < size_; i++)
	{
		if (f_dis[date_set[i]] > mid)
		{
			d_s.push_back(date_set[i]);
		}
	}
	return d_s;
}

void MeshCut::get_two_bound_points(Mesh& m, std::vector<int>& bound_points_)
{
	bound_points_.clear(); bound_points_.resize(2);
	int max_x_idx = -1, min_x_idx = -1, max_y_idx = -1, min_y_idx = -1, max_z_idx = -1, min_z_idx = -1;
	double max_x = -10000, min_x = 10000, max_y = -10000, min_y = 10000, max_z = -10000, min_z = 10000;
	unsigned counter = 0;
	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		OpenMesh::Vec3d p = m.point(*v_it);
		if (p[0] > max_x)
		{
			max_x = p[0];
			max_x_idx = counter;
		}
		if (p[0] < min_x)
		{
			min_x = p[0];
			min_x_idx = counter;
		}
		if (p[1] > max_y)
		{
			max_y = p[1];
			max_y_idx = counter;
		}
		if (p[1] < min_y)
		{
			min_y = p[1];
			min_y_idx = counter;
		}
		if (p[2] > max_z)
		{
			max_z = p[2];
			max_z_idx = counter;
		}
		if (p[2] < min_z)
		{
			min_z = p[2];
			min_z_idx = counter;
		}
		counter++;
	}

	double x_scale = max_x - min_x;
	double y_scale = max_y - min_y;
	double z_scale = max_z - min_z;
	if (x_scale >= y_scale && x_scale >= z_scale)
	{
		bound_points_[0] = max_x_idx; bound_points_[1] = min_x_idx;
	}
	else if (y_scale >= x_scale && y_scale >= z_scale)
	{
		bound_points_[0] = max_y_idx; bound_points_[1] = min_y_idx;
	}
	else
	{
		bound_points_[0] = max_z_idx; bound_points_[1] = min_z_idx;
	}
}