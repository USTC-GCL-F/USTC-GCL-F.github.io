#include "MatrixUDG.h"
#include <iostream>

MatrixUDG::MatrixUDG(void)
{

}

MatrixUDG::~MatrixUDG(void)
{
	if (find_geodesic1) delete find_geodesic1;
	find_geodesic1 = nullptr;
}

MatrixUDG::MatrixUDG(const Mesh & mesh_, std::vector<int> & vertex)
{
	my_mesh1 = mesh_;
	input_vertex1 = vertex;
	nv = input_vertex1.size();
	ne = nv*(nv - 1) / 2;
	//�����ڽӾ��󣨽�Ȩ�ؼ������
	find_geodesic1 = new Findgeodesic(my_mesh1);
	weight_Matrix.resize(nv, nv);

	//std::cout << "�ڽӾ���Ȩ��" << std::endl;
	/*shortest_edges1.clear();
	for (int i = 0; i < nv; ++i)
	{
		for (int j = i; j < nv; ++j)
		{
			if (i == j)
			{
				weight_Matrix(i, j) = 0;
			}
			else
			{
				shortest_edges1.push_back(find_geodesic1->Find_Geodesic(input_vertex1[i], input_vertex1[j]));
				weight_Matrix(i, j) = find_geodesic1->distance_weight;
				weight_Matrix(j, i) = weight_Matrix(i, j);
			}
		}
	}*/

	shortest_edges1.clear();
	std::vector<int> is_target(my_mesh1.n_vertices(), false);
	for (int i = 0; i < nv; i++)
	{
		is_target[input_vertex1[i]] = true;
	}
	weight_Matrix(nv-1, nv-1) = 0;
	for (int i = 0; i < nv-1; i++)
	{
		is_target[input_vertex1[i]] = false;
		find_geodesic1->Find_Geodesic(input_vertex1[i], is_target, nv - i - 1);
		weight_Matrix(i, i) = 0;
		for (int j = i+1; j < nv; j++)
		{
			//std::cout << i*(nv - 1) + j - 1 << " ** " << j*(nv - 1) + i << std::endl;
			std::vector<int>  path1 = find_geodesic1->searchPath(input_vertex1[i], input_vertex1[j]);
			shortest_edges1.push_back(path1);
			weight_Matrix(i, j) = find_geodesic1->dist[input_vertex1[j]];
			weight_Matrix(j, i) = weight_Matrix(i, j);
		}
		//std::cout<< std::endl;
	}
	std::cout << " ** initial endl ! " << std::endl;

	int edges_number1 = my_mesh1.n_edges();
	int vertices_number1 = my_mesh1.n_vertices();
	visit_or_not1.clear();
	visit_or_not1.resize(edges_number1, -1);//��ʼ�����еı߶�δ������
	visit_or_not_vertex1.clear();
	visit_or_not_vertex1.resize(vertices_number1, -1);//��ʼ�����еĵ㶼δ������
}

MatrixUDG::MatrixUDG(Mesh & mesh_, std::vector<int> & vertex, std::vector<std::vector<double>> & edges_wei)
{
	my_mesh1 = mesh_;
	input_vertex1 = vertex;
	nv = input_vertex1.size();
	ne = nv*(nv - 1) / 2;
	//�����ڽӾ��󣨽�Ȩ�ؼ������
	//find_geodesic1 = new Findgeodesic(my_mesh1);
	find_geodesic1 = new Findgeodesic();
	find_geodesic1->set_mesh(my_mesh1);
	find_geodesic1->set_edges_weight(edges_wei);

	weight_Matrix.resize(nv, nv);

	//std::cout << "�ڽӾ���Ȩ��" << std::endl;
	/*shortest_edges1.clear();
	for (int i = 0; i < nv; ++i)
	{
	for (int j = i; j < nv; ++j)
	{
	if (i == j)
	{
	weight_Matrix(i, j) = 0;
	}
	else
	{
	shortest_edges1.push_back(find_geodesic1->Find_Geodesic(input_vertex1[i], input_vertex1[j]));
	weight_Matrix(i, j) = find_geodesic1->distance_weight;
	weight_Matrix(j, i) = weight_Matrix(i, j);
	}
	}
	}*/

	shortest_edges1.clear();
	std::vector<int> is_target(my_mesh1.n_vertices(), false);
	for (int i = 0; i < nv; i++)
	{
		is_target[input_vertex1[i]] = true;
	}
	weight_Matrix(nv - 1, nv - 1) = 0;
	for (int i = 0; i < nv - 1; i++)
	{
		is_target[input_vertex1[i]] = false;
		find_geodesic1->Find_Geodesic(input_vertex1[i], is_target, nv - i - 1);
		weight_Matrix(i, i) = 0;
		for (int j = i + 1; j < nv; j++)
		{
			//std::cout << i*(nv - 1) + j - 1 << " ** " << j*(nv - 1) + i << std::endl;
			std::vector<int>  path1 = find_geodesic1->searchPath(input_vertex1[i], input_vertex1[j]);
			shortest_edges1.push_back(path1);
			weight_Matrix(i, j) = find_geodesic1->dist[input_vertex1[j]];
			weight_Matrix(j, i) = weight_Matrix(i, j);
		}
		//std::cout<< std::endl;
	}
	std::cout << " ** initial endl ! " << std::endl;

	int edges_number1 = my_mesh1.n_edges();
	int vertices_number1 = my_mesh1.n_vertices();
	visit_or_not1.clear();
	visit_or_not1.resize(edges_number1, -1);//��ʼ�����еı߶�δ������
	visit_or_not_vertex1.clear();
	visit_or_not_vertex1.resize(vertices_number1, -1);//��ʼ�����еĵ㶼δ������
}

void MatrixUDG::kruskal()
{
	int p1, p2;
	int m, n;

	std::vector<int> spanning_tree_current;//�����������ж����������Ƿ���ͨ
	spanning_tree_current.resize(nv);
	//��ʼ����������
	for (int i = 0; i < nv; ++i)
	{
		spanning_tree_current[i] = i;
	}

	std::vector<EData> edges;//ͼ�е����б�
	int index = 0;//edges�������±��0��ʼ
	//��Ȩ�ضԱߴ�С�����������
	edges = getEdges();
	for (int i = 0; i < ne; ++i)
	{
		for (int j = i + 1; j < ne; ++j)
		{
			if (edges[i].weight>edges[j].weight)
			{
				std::swap(edges[i], edges[j]);//����������
				std::swap(shortest_edges1[i], shortest_edges1[j]);//���������߶�Ӧ�����·������
			}
		}
	}

	index = 1;
	int j = 0;
	//��ǵ�һ�����·���ϵĵ�Ϊ����
	for (int h = 0; h < shortest_edges1[0].size(); ++h)
	{
		visit_or_not_vertex1[shortest_edges1[0][h]] = 1;
	}
	//�������landmarks�ķ������Ϊ0
	for (int k = 0; k < input_vertex1.size(); ++k)
	{
		visit_or_not_vertex1[input_vertex1[k]] = 0;
	}

	while (index < nv)
	{
		//�õ������������ڵļ��ϱ��
		m = spanning_tree_current[getPosition(edges[j].start)];
		n = spanning_tree_current[getPosition(edges[j].end)];
		//���������㲻��ͬһ�����ϱ���У��򽫸ñ߼�����С������
		if (m != n)
		{
			//�洢��ǰ��j�����·���ϵıߵ�����
			std::vector<int> shortest_edges_index1;
			std::vector<int> shortest_edges_index2;
			int same_edges_number1 = 0;
			int same_edges_number2 = 0;

			for (int k = 0; k < shortest_edges1[j].size() - 1; ++k)
			{
				for (auto halfedge = my_mesh1.voh_iter(my_mesh1.vertex_handle(shortest_edges1[j][k])); halfedge.is_valid(); ++halfedge)
				{
					int halfedge_vertex = my_mesh1.to_vertex_handle(*halfedge).idx();
					if (halfedge_vertex == shortest_edges1[j][k + 1])
					{
						shortest_edges_index1.push_back(my_mesh1.edge_handle(*halfedge).idx());
						if (visit_or_not1[my_mesh1.edge_handle(*halfedge).idx()] == -1)
						{
							visit_or_not1[my_mesh1.edge_handle(*halfedge).idx()] = 1;//��Ǹñ��Ѿ������ʣ��Ѿ�������С�������У�
						}
						else
						{
							same_edges_number1++;
						}
					}
				}
			}

			if (same_edges_number1 > 0)
			{
				//std::vector<int> shortest_edges_current;
				//std::cout <<"change geodesic: "<<same_edges_number1 << std::endl;
				//shortest_edges_current = find_geodesic1->Change_Geodesic(shortest_edges1[j][0], shortest_edges1[j][shortest_edges1[j].size() - 1], visit_or_not_vertex1);
				//shortest_edges1[j] = shortest_edges_current;
			}

			//�ñ߼�����С������
			spanning_tree_path.push_back(edges[j]);
			//�ñ���㵽�յ�����·��������С��������Ӧ������·����
			spanning_tree_edges1.push_back(shortest_edges1[j]);

			for (int k = 0; k < shortest_edges1[j].size(); ++k)
			{
				visit_or_not_vertex1[shortest_edges1[j][k]] = 1;
			}
			for (int k = 0; k < input_vertex1.size(); ++k)
			{
				visit_or_not_vertex1[input_vertex1[k]] = 0;
			}

			index++;
			for (int i = 0; i < nv; ++i)
			{
				if (spanning_tree_current[i] == n)
				{
					spanning_tree_current[i] = m;
				}
			}
		}
		j++;
	}
}

std::vector<EData> MatrixUDG::getEdges()
{
	int index = 0;
	std::vector<EData> edges;
	edges.resize(ne);

	for (int i = 0; i < nv; ++i)
	{
		for (int j = i + 1; j < nv; ++j)
		{
			edges[index].start = input_vertex1[i];
			edges[index].end = input_vertex1[j];
			edges[index].weight = weight_Matrix(i, j);
			index++;
		}
	}
	return edges;
}

int MatrixUDG::getPosition(int index)
{
	for (int i = 0; i < nv; ++i)
	{
		if (input_vertex1[i] == index)
		{
			return i;
		}
	}
	return -1;
}