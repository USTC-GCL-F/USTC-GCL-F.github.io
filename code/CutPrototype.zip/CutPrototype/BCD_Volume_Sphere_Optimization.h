#ifndef BCD_Volume_Sphere_Optimization_H
#define BCD_Volume_Sphere_Optimization_H

#include "MeshDefinition.h"
#include "graph_coloring.h"
#include <Eigen/Dense>
#include <omp.h>
#include "fmath.hpp"

class BCD_Volume_Sphere_Optimization
{
public:
	BCD_Volume_Sphere_Optimization();
	~BCD_Volume_Sphere_Optimization();

	void SetMesh(Mesh* mesh)
	{
		reset_all_State();
		mesh_ = mesh;
	}
	void reset_all_State();
	//2016.8.29, try to optimize the sphere triangle through volume energy.
	void prepare_data();
	void optimize_sphere_volume(double ep, int max_iter);
	void compute_distortion();
	double max_iso_distortion();
	double max_iso_local_distortion(Mesh::VertexHandle &v,double r);
	bool checklap(Mesh* mesh_, double threh);
	void SetThreshhold(double min_l, double min_v)
	{
		m_l = min_l;
		m_v = min_v;
	}

	//2016.10.13, try optimize the sphere triangle in the process of move landmarks
	void prepare_data_sph_mesh();
	void optimize_sphere_landmarks_volume(double ep, int max_iter, std::vector<double>& new_x, std::vector<double>& new_y, std::vector<double>& new_z, std::vector<int>& landmarks_);
	double max_iso_sph_distortion(std::vector<double>& new_x, std::vector<double>& new_y, std::vector<double>& new_z, bool is_updata);
	void compute_sph_distortion(std::vector<double>& new_x, std::vector<double>& new_y, std::vector<double>& new_z);

private:
	Mesh* mesh_;
	bool prepare_OK;

	double C00, C01, C02, C10, C11, C12, C20, C21, C22; Eigen::Matrix3d SI;
	double energy_power; double high_d; double radius;
	std::vector<std::vector<int>> v_same_color;
	std::vector<std::vector<int>> v_fv_id;
	std::vector<OpenMesh::Vec3d> v_pos;
	std::vector<double> vertex_radius_ratio;
	
	void optimize_sphere_volume_one_V(int v_id, int omp_id);
	bool locally_check_negative_volume(Mesh::VertexHandle& vh, OpenMesh::Vec3d& np);
	bool locally_check_negative_volume(OpenMesh::Vec3d& np, int size_vfv, std::vector<int>& one_v_fv_id);
	double compute_local_exp_mips_energy(Mesh::VertexHandle& vh, OpenMesh::Vec3d& np);
	double compute_local_exp_mips_energy(OpenMesh::Vec3d& np, int size_vfv, std::vector<int>& one_v_fv_id);

	// add by huxin
	double m_l, m_v;
	double local_mips_energy;
	fmath::PowGenerator *f;
	bool is_current_max_iso;

	// add by huxin -> store object sphere tetrahedron information
	std::vector< std::vector<double> > C00_, C01_, C02_, C10_, C11_, C12_, C20_, C21_, C22_;
	std::vector<Eigen::Matrix3d, Eigen::aligned_allocator<Eigen::Matrix3d>> SI_;
	void optimize_sphere_landmarks_volume_one_V(int v_id, int omp_id);
	double compute_local_exp_mips_energy(OpenMesh::Vec3d& np, int size_vfv, std::vector<int>& one_v_fv_id, std::vector<double>& c00, std::vector<double>& c01,
		std::vector<double>& c02, std::vector<double>& c10, std::vector<double>& c11, std::vector<double>& c12, std::vector<double>& c20, std::vector<double>& c21, std::vector<double>& c22);
};

#endif