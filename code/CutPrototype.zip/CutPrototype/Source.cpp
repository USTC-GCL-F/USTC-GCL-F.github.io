#include "CutApp.h"
int main(int argc, char * argv[])
{
	auto && app = CutApp::GetInstance();
	if (!app.ParseCommand(argc, argv))
	{
		return 1;
	}
	if (!app.Run())
	{
		return 2;
	}
	return 0;
}