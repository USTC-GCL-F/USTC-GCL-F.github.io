#pragma once
#include "MeshDefinition.h"
#include "BCD_Sphere_Optimization.h"
#include "BCD_Volume_Sphere_Optimization.h"
#include <queue>
#include "General_Struct.h"


struct LastMesh
{
	std::vector<Mesh::Point> last_position;
	std::vector<Eigen::Vector3i> last_triangle;
	std::vector<int> collapse_vindex;
	std::vector<int>  index_collapse_v_to_v;
	//	std::vector<int>  neighbors_v;
};

//struct EdgeInfo
//{
////	int edge_id;
//	Mesh::HalfedgeHandle idx;
//	double ecost;
//	inline    friend bool      operator<(const EdgeInfo & lhs, const EdgeInfo & rhs) { return (lhs.ecost < rhs.ecost);}
//	inline    friend bool      operator>(const EdgeInfo & lhs, const EdgeInfo & rhs) { return (lhs.ecost > rhs.ecost);}
//};
//
//struct EdgeInfo_
//{
//	//	int edge_id;
//	Mesh::HalfedgeHandle idx;
//	double ecost;
//	inline    friend bool      operator<(const EdgeInfo_ & lhs, const EdgeInfo_ & rhs) { return (lhs.ecost > rhs.ecost); }
//	inline    friend bool      operator>(const EdgeInfo_ & lhs, const EdgeInfo_ & rhs) { return (lhs.ecost < rhs.ecost); }
//};
//
//struct EdgeQEM
//{
//	Mesh::EdgeHandle idx;
//	double qem;
//	inline    friend bool      operator<(const EdgeQEM & lhs, const EdgeQEM & rhs) { return (lhs.qem > rhs.qem); }
//	inline    friend bool      operator>(const EdgeQEM & lhs, const EdgeQEM & rhs) { return (lhs.qem < rhs.qem); }
//};

class HierarchicalSphereParametrization
{
public:
	HierarchicalSphereParametrization(Mesh &mesh); // ��ʼ����
	~HierarchicalSphereParametrization(void);
public:
	/////////////////////////////////////////////////////////////////////////////////////////////// simplify the mesh to a tetrahedron
	std::vector<std::vector<int>> do_Simplify();
	bool Choose_Collapased_edge(Mesh &m); // ѡ��Ҫ�� collapsed �İ��
	bool Choose_Collapased_edge_qem(Mesh &m, double err_threshhold); // ���� qem ׼��ѡ��Ҫ�� collapsed �İ��
	void Initial_Halfedge_Cost(Mesh &m);  // ����ÿһ����ߵ�ֵ��������Ϣ����ecost�����У��˺���ֻ������һ��
	void Initial_Edge_QEM_cost(Mesh &m); // ����ÿ���ߵ�qemֵ�� ������Ϣ�洢��QuaMat_e�У��˺���ֻ������һ��
	void Update_Edge_QEM_cost(Mesh &m, int i);  // collapsed ֮����¾ֲ��ߵ�qem��Ϣ
	void Update_Halfedge_Cost(Mesh &m, int i); // collapsed ֮����¾ֲ���ߵ���Ϣ
	void QEM_Simplify(int tar_num_v, double err_threshhold);
	void LaplacianSmooth(Mesh &m, int iter_num_);
	void calc_vindex(Mesh& m); // Ϊÿ��������������ԭʼ�������ֵ��������vindex��
	//	bool Is_exist_fliping(Mesh &m);
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////   project to a sphere , and then subdivide to original topology
	void Subdivision(int num_optimization_, std::vector<std::vector<int>> &idx_v_to_v);
	bool Restore_Last_mesh(Mesh &m, std::vector<int> &reco_info); // ����reco_info�е���Ϣ�ָ���һ��������
	bool Add_One_Point(Mesh &m, Mesh::VertexHandle v_f, Mesh::VertexHandle v_t, int c); // ���ò����ķ�ʽ�����µĶ���
	bool local_check_negative_area(Mesh::Point &p, std::vector<Mesh::Point> &n_p); // �ж��Ƿ����Խ�
	double local_isotropy_energy(Mesh::Point &p, std::vector<Mesh::Point> &np1, std::vector<Mesh::Point> &np2, double area_); // ���۲�����ĺû�
	void Compute_idx_to_idx_corresponding(Mesh &m);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// support function
	double ComputeSphereRadius(Mesh &m);
	void calc_origin_position(Mesh& m);
	Mesh::VertexHandle ComputeBihedralAngles(const Mesh &m, const Mesh::VertexHandle &idx);
	bool OptimizeOneRing(Mesh &m, const Mesh::VertexHandle &idx, Mesh::VertexHandle v_t, int c);
	void PrintInfo(std::string fileName);
	void RefineModel(Mesh &m, double thresh_hold, double r);

	void Initial_Halfedge_Cost_pengchao(Mesh &m);
	void Update_Halfedge_Cost_pengchao(Mesh &m, int i);
	bool Choose_Collapased_edge_pengchao(Mesh &m);

public:
	Mesh origin_mesh;
	Mesh initial_mesh;
	Mesh copy_origin_mesh;
	Mesh copy_origin_mesh1;

private:
	std::vector<std::vector<int>> index_collapse_v_to_v; // �洢�ָ�ʱ��Ҫ�õ���������Ϣ
	std::vector<Mesh::Point> o_p;
	OpenMesh::VPropHandleT<int> vindex; // �洢��������
	OpenMesh::HPropHandleT<double> ecost; // �洢�������
	OpenMesh::HPropHandleT<bool> is_cal_he;
	OpenMesh::VPropHandleT<Mesh::Point> origin_position; // �洢ԭʼ����Ķ���λ��
	OpenMesh::VPropHandleT<Eigen::Matrix4d> QuaMat_v;
	OpenMesh::FPropHandleT<Eigen::Matrix4d> QuaMat_f;
	OpenMesh::FPropHandleT<double> area_f;
	OpenMesh::EPropHandleT<double> QuaMat_e;
	OpenMesh::EPropHandleT<OpenMesh::Vec3d> new_point;
	//OpenMesh::EPropHandleT<double> edge_l;
	OpenMesh::EPropHandleT<bool> is_cal_e;
	std::vector<LastMesh> recover_information;
	int n_vertices;
	int n_edges;
	int n_faces;
	int current_num_v;
	int current_num_e;
	int current_num_f;
	bool first_sub;
	double maxmum;
	bool is_in_sphere;
	std::priority_queue<EdgeInfo> epq;
	std::priority_queue<EdgeQEM> qpq;
	std::vector<int> idx_to_idx_corresponding;

	std::priority_queue<EdgeInfo_> epq_p;

public:
	std::vector<int> nei_ps1, nei_ps2;
	BCD_Sphere_Optimization * bcd_optimization;
	BCD_Volume_Sphere_Optimization * bcd_v_optimization;
	double global_max_energy;
	std::vector<int> recore_add_v_nun;
	std::vector<double> record_max_dis;
	double radius;
	std::vector<int> simplified_mesh;

};
