#pragma once
//#  define BOOST_NO_CXX11_VARIADIC_TEMPLATES  // ָʾ��������֧��variadic template

#include <iostream>
#include <string>
#include <fstream>
#include "time.h"
#include "MeshDefinition.h"

/*
N: The number of the vertices
graph_color_edge: the edge collection
v_same_color: the vertices with same color are stored in one vector
*/
void graph_coloring(int N, std::vector<OpenMesh::Vec2i>& graph_color_edge, std::vector< std::vector<int> >& v_same_color);
