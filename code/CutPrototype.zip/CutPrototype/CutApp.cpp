#include <OpenMesh/Core/IO/MeshIO.hh>
#include "CutApp.h"
#include "MeshCut.h"
#include "MatrixUDG.h"
#include "HierarchicalSphereParametrization.h"
#include <iostream>
#include <fstream>

CutApp::CutApp(void)
	:iscutorigin(false),
	isdospherical(false)
{
}

CutApp::~CutApp(void)
{
}

CutApp& CutApp::GetInstance(void)
{
	static CutApp instance;
	return instance;
}

bool CutApp::ParseCommand(int argc, char * argv[])
{
	std::vector<int> filenameid;
	for (int i = 1; i < argc; i++)
	{
		if (argv[i][0] == '-') // options
		{
			switch (argv[i][1])
			{
			case 'o':
				iscutorigin = true;
				break;
			default:
				PrintError();
				return false;
				break;
			}
		}
		else
		{
			filenameid.push_back(i);
		}
	}

	if (filenameid.size() == 1)
	{
		isdospherical = true;
	}
	else if (filenameid.size() == 2)
	{
		isdospherical = false;
		spherefilename = argv[filenameid[1]];
		std::ifstream ifs(spherefilename);
		if (!ifs.is_open())
		{
			std::cerr << "Error: the file " << spherefilename << " does not exist." << std::endl;
			return false;
		}
		ifs.close();
	}
	else
	{
		PrintError();
		return false;
	}
	meshfilename = argv[filenameid[0]];
	std::ifstream ifs(meshfilename);
	if (!ifs.is_open())
	{
		std::cerr << "Error: the file " << spherefilename << " does not exist." << std::endl;
		return false;
	}
	ifs.close();

	meshpath = ".";
	auto slash = meshfilename.find_last_of('/');
	auto backslash = meshfilename.find_last_of('\\');
	if (slash != std::string::npos && backslash != std::string::npos)
	{
		slash = slash > backslash ? slash : backslash;
		meshpath = meshfilename.substr(0, slash);
	}
	else if (backslash != std::string::npos)
	{
		slash = backslash;
		meshpath = meshfilename.substr(0, slash);
	}
	else if (slash != std::string::npos)
	{
		meshpath = meshfilename.substr(0, slash);
	}

	meshbasename = meshfilename.substr(slash + 1);
	auto point = meshbasename.find_last_of('.');
	if (point != std::string::npos)
	{
		meshbasename = meshbasename.substr(0, point);
	}

	return true;
}

bool CutApp::Run(void)
{
	bool readok = OpenMesh::IO::read_mesh(mesh, meshfilename);
	if (!readok)
	{
		std::cout << "Error: Cannot load mesh from file " << meshfilename << "." << std::endl;
		return false;
	}
	orimesh = mesh;
	if (isdospherical)
	{
		HierarchicalSphereParametrization *hsp = new HierarchicalSphereParametrization(mesh);
		std::vector<std::vector<int>> idx_to_idx = hsp->do_Simplify();
		hsp->Subdivision(1, idx_to_idx);
		mesh = hsp->origin_mesh;
		delete hsp;
		hsp = nullptr;
	}
	else
	{
		mesh.clear();
		readok = OpenMesh::IO::read_mesh(mesh, spherefilename);
		if (!readok)
		{
			std::cout << "Error: Cannot load mesh from file " << spherefilename << "." << std::endl;
			return false;
		}
	}
	CutMesh();
	return true;
}

void CutApp::PrintError(void)
{
	std::cerr << "ERROR: wrong argument." << std::endl;
	std::cout << "Usage: CutPrototype <mesh1> [mesh2] [-o]" << std::endl;
	std::cout << "Parameters: mesh1: a genus zero mesh." << std::endl;
	std::cout << "            mesh2: a spherical parameterization mesh." << std::endl;
	std::cout << "                   if this parameter is not specified, the program" << std::endl;
	std::cout << "                   will compute a spherical parameterization." << std::endl;
	std::cout << "            -o   : cut on the original mesh." << std::endl;
	std::cout << "                   if not specified, cut on the sphere." << std::endl;
}

void CutApp::CutMesh(void)
{
	std::vector<OpenMesh::Vec3d> s_c_p; // data set to cluster
	std::vector<int> s_c_p_idx;
	MeshCut *cut_mesh_ = new MeshCut;
	cut_mesh_->set_mesh(orimesh);
	cut_mesh_->prepare_compute_distortion();
	cut_mesh_->compute_all_triangle_dis(mesh, 0.5);
	for (int i = 0; i < cut_mesh_->f_dis.size(); i++)
	{
		if (mesh.is_boundary(mesh.face_handle(i)))
		{
			continue;
		}
		if (cut_mesh_->f_dis[i] > 0)
		{
			Mesh::FaceVertexIter fv_it = mesh.cfv_iter(mesh.face_handle(i));
			OpenMesh::Vec3d p = mesh.point(*fv_it); ++fv_it;
			p += mesh.point(*fv_it); ++fv_it;
			p += mesh.point(*fv_it);
			p /= 3.0;
			s_c_p.push_back(p);
			s_c_p_idx.push_back(i);
		}

	}
	cut_mesh_->clustered_points_separate(mesh, s_c_p_idx, 0.0015 * mesh.n_faces());
	std::vector<int> selected_points = cut_mesh_->c_p_idx;
	
	std::ofstream SaveFile(meshpath + "/" + meshbasename + "_landmarks.txt");
	if (SaveFile.is_open())
	{
		for (int i = 0; i < selected_points.size(); i++)
		{
			SaveFile << selected_points[i] << std::endl;
		}
		SaveFile.close();
	}
	else
	{
		std::cerr << "ERROR: cannot save landmarks" << std::endl;
	}

	MatrixUDG *cut_points_ = iscutorigin ? new MatrixUDG(orimesh, selected_points) : new MatrixUDG(mesh, selected_points);
	cut_points_->kruskal();
	std::vector<std::vector<int>> boundary_p = cut_points_->spanning_tree_edges1;
	delete cut_points_;
	cut_points_ = nullptr;
	std::vector<int> boundarypoints;
	for (int i = 0; i < boundary_p.size(); i++)
	{
		for (int j = 0; j < boundary_p[i].size(); j++)
		{
			boundarypoints.push_back(boundary_p[i][j]);
		}
	}
	cut_mesh_->mesh_cut(boundarypoints, "cut1.obj", true);

	std::ofstream ofs(meshpath + "/" + meshbasename + "_cut.txt");
	ofs << "VERTICES" << std::endl;
	std::set<int> cutEdges, cutVertices;
	for (size_t i = 0; i < cut_mesh_->candidate_seam_vertex.size(); i++)
	{
		if (cut_mesh_->candidate_seam_vertex[i])
		{
			cutVertices.insert((int)i);
			ofs << i << std::endl;
		}
	}
	ofs << "EDGES" << std::endl;
	for (size_t i = 0; i < cut_mesh_->candidate_seam_edge.size(); i++)
	{
		if (cut_mesh_->candidate_seam_edge[i])
		{
			cutEdges.insert((int)i);
			ofs << i << std::endl;
		}
	}
	ofs.close();

	std::string savefilename = meshpath + "/" + meshbasename + "_open.obj";
	bool saveok = OpenMesh::IO::write_mesh(cut_mesh_->cuted_mesh, savefilename);
	if (!saveok)
	{
		std::cerr << "Error: Cannot save mesh to file " << savefilename << "." << std::endl;
		return;
	}
}