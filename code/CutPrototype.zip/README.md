CutPrototype
===

This is a C++ implementation of the cut construction method in "Sphere-based Cut Construction for Planar Parameterizations".
The code is compiled using Microsoft Visual Studio 2017 with OpenMP support for parallel programming.

Library
---

* [boost](https://www.boost.org/)
* [Eigen](http://eigen.tuxfamily.org/)
* [OpenMesh](https://www.openmesh.org/)
* OpenMP support

Usage
---

```
CutPrototype <mesh1> [mesh2] [-o]
```

Command arguments:
* mesh1: a genus zero mesh.
* mesh2: a spherical parameterization mesh. If this parameter is not specified, the program will compute a spherical parameterization.
* -o: cut on the original mesh. If not specified, cut on the sphere.
