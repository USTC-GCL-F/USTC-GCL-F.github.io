window.onload = function(){

    document.querySelector("#hefeihuochezhan").onclick = function(){
        document.querySelector("#hefeihuochezhan_position").scrollIntoView(true);
    }
    document.querySelector("#hefeigaotienanzhan").onclick = function(){
        document.querySelector("#hefeigaotienanzhan_position").scrollIntoView(true);
    }
    document.querySelector("#hefeixinqiaojichang").onclick = function(){
        document.querySelector("#hefeixinqiaojichang_position").scrollIntoView(true);
    }
}
